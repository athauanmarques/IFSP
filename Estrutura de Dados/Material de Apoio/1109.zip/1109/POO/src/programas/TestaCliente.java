package programas;

import javax.swing.JOptionPane;

import classes.exercicio01.Banco;
import classes.exercicio01.Cliente;

public class TestaCliente {

	public static void main(String[] args) {
		Cliente cliente = new Cliente();
		cliente.setCpf(JOptionPane.showInputDialog("CPF do cliente:"));
		cliente.setNome(JOptionPane.showInputDialog("Nome do cliente"));
		
		Banco banco = new Banco();
		banco.setNomeBanco(JOptionPane.showInputDialog("Nome do Banco:"));
		banco.setNumAgencia(Integer.parseInt(JOptionPane.showInputDialog("Numero da Agencia")));
		banco.setNumBanco(Integer.parseInt(JOptionPane.showInputDialog("Numero do banco: ")));
		banco.setNumConta(JOptionPane.showInputDialog("Numero da Conta"));
		
		//agrega��o do banco ao cliente
		
		String opcoes = "Escolha um op��o: " +
		                "\n\n 1 - Saque" +
				        "\n 2 - Dep�sito" +
		                " \n 3 - Saldo " +
				        " \n 4> - Sair";
		while(true){
			int opcao = Integer.parseInt(JOptionPane.showInputDialog(opcoes));
			switch (opcao){
			case 1: {
				double valor = Integer.parseInt(JOptionPane.showInputDialog("Valor do Saque:"));
				
				if (!banco.efetuarSaque(valor)){
					JOptionPane.showMessageDialog(null,"N�o foi poss�vel realizar o saque!");
					
				}
			}
			break;
			case 2:{
			    double valor = Double.parseDouble(JOptionPane.showInputDialog("Valor de Deposito:"));
			    
			    if (!banco.efetuarSaque(valor)){
					JOptionPane.showMessageDialog(null,"N�o foi poss�vel realizar o saque!");
			    }
			}
			break;
			case 3: {
				 JOptionPane.showMessageDialog(null,cliente.);
			    
			}
			}
			}
		}
		            
		

	}

}
