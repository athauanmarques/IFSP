package classes;

import classes.exercicio01.Cliente;

public class Metodo {
	/*
	 * 
	 * 
	 * M�todo est�tico:n�o depende de objetos para ser executado;
	 * Este m�todo est�tico n�o pode acessar nenhum atributo de classe;
	 * Portanto, ele n�o tem acesso � palavra reservada this.  
	 */
	public static String turma;
	public static String exibirAutor(){
		turma ="EDS1";
		return "Turma de An�lise e Desenvol. Sistemas 2013";
		
	}
	public static void mostrar(Cliente c){
		System.out.println(c.getNome());
						
	}
	
}
