package classes;

public class Endereco {
  private String rua,nome, bairro;
  private int num;
  
public String getRua() {
	return rua;
}
public void setRua(String rua) {
	this.rua = rua;
}
public String getNome() {
	return nome;
}
public void setNome(String nome) {
	this.nome = nome;
}
public String getBairro() {
	return bairro;
}
public void setBairro(String bairro) {
	this.bairro = bairro;
}
public int getNum() {
	return num;
}
public void setNum(int num) {
	this.num = num;
}
  
  
	
}
