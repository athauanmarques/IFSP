package classes.exercicio01;

public class Banco {
	
	
	private int numBanco, numAgencia;
	private String numConta, nomeBanco;
	private double saldo;
	public int getNumBanco() {
		return numBanco;
	}
	public void setNumBanco(int numBanco) {
		this.numBanco = numBanco;
	}
	public int getNumAgencia() {
		return numAgencia;
	}
	public void setNumAgencia(int numAgencia) {
		this.numAgencia = numAgencia;
	}
	public String getNumConta() {
		return numConta;
	}
	public void setNumConta(String numConta) {
		this.numConta = numConta;
	}
	public String getNomeBanco() {
		return nomeBanco;
	}
	public void setNomeBanco(String nomeBanco) {
		this.nomeBanco = nomeBanco;
	}
	public double getSaldo() {
		return saldo;
	}
	// o saldo receber� um valor apenas por opera��es realizadas
	//na pr�pria classe.
	//Fora da classe n�o poderemos acess�-lo.
	
	private void setSaldo(double saldo) {
		this.saldo = saldo;
	}
	
	//opera��es: saque, deposito
	public boolean efetuarSaque(double valor){
		
		if ((this.getSaldo() >= valor) && (valor > 0)){
			this.setSaldo(this.getSaldo() - valor);
			return true;
		}
		return false;
	}
	public boolean efetuarDeposito(double valor){
		if (valor > 0){
			this.setSaldo(this.getSaldo() + valor);
			return true;
		}
		return false;
	}
	public String exibirDadosBanco(){
		String resultado = "DADOS BANC�RIOS: " + 
	                     "\nNome Banco: " + this.getNomeBanco() +
	                     "\nNumero Banco: " + this.getNumBanco() +
	                     "\nNumero Ag�ncia: " + this.getNumAgencia() +
	                     "\nConta: " + this.getNumConta() +
		                 "\nSaldo: " + this.getSaldo();
		return resultado;
		
	}
}
