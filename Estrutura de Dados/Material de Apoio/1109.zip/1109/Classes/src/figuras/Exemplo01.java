package figuras;

public class Exemplo01 {
	public static void main(String[] args) {
		
		
		Circulo c = new Circulo();
		c.exibir();
	}

}
