package figuras;

public class Circulo {
	//int n;
	public void exibir(){
		System.out.println("Exibir nosso primeiro metodo");
	}

}
