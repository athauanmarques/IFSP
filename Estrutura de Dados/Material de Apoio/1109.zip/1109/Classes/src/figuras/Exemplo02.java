package figuras;

public class Exemplo02 {
	public static void main (String args[]){
		String texto = new String ();
		Circulo c = new Circulo();
		
	}
	
}
