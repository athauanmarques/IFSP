
public class ExemploAtribuicao {

	public static void main(String[] args) {
		Pessoa juliana = new Pessoa();
		Pessoa jefferson = new Pessoa();
		
		juliana.setIdade();
		jefferson.setIdade();
	}

}
