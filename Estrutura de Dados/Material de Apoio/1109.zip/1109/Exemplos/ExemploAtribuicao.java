package classes.exercicio01;


public class ExemploAtribuicao {

	public static void main(String[] args) {
		
		
		
		
