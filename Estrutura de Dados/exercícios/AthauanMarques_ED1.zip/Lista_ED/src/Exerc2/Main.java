package Exerc2;

import java.util.ArrayDeque;
import java.util.Queue;

import javax.swing.JOptionPane;

import Exerc1.Numeros;

public class Main {

	public static void main(String[] args) {
		
		int numero, opcao;
		Queue<Numeros> fila = new ArrayDeque<Numeros>();
		
		do{
			Numeros n = new Numeros();
			numero = Integer.parseInt(JOptionPane.showInputDialog("Informe um numero inteiro: "));
			n.setNumero(numero);
			fila.add(n);
			opcao = Integer.parseInt(JOptionPane.showInputDialog("Deseja inserir mais numeros \n1.Sim \n2.N�o"));
			
		}while(opcao == 1);
		
		int menorNum = Integer.MAX_VALUE, i = 0;
		String listaNum = "";
		
		while(!fila.isEmpty()){
			i++;
			Numeros n = fila.remove();
			listaNum += i+ "� " + "Numero: " + n.getNumero() + "\n";
									
			if (n.getNumero() < menorNum) {
				menorNum = n.getNumero();
			}
		}
		JOptionPane.showMessageDialog(null,"Lista de Numeros Informados: \n" + listaNum +"\nO Menor numero �: " + menorNum);
	}

}
