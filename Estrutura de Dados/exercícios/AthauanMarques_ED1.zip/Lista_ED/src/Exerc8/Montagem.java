package Exerc8;

public class Montagem {
	String peca;

	public String getPeca() {
		return peca;
	}

	public void setPeca(String peca) {
		this.peca = peca;
	}

}
