package Exerc8;

import Exerc8.Montagem;

import java.util.ArrayDeque;
import java.util.Deque;

import javax.swing.JOptionPane;

public class Main {

	public static void main(String[] args) {
		
		Deque<Montagem> pilha = new ArrayDeque<Montagem>();
		String opcao, listaPeca1 = "", listaPeca2 = "";
		
		do{
			opcao =JOptionPane.showInputDialog("1.Inserir Pe�as \n2.Lista Pe�as "
					+ "\n3.Desmontar \n4.Sair");
			
			if(opcao.equals("1")){
				Montagem m = new Montagem();
				m.setPeca(JOptionPane.showInputDialog("Informe o Nome da pe�a: "));
				pilha.push(m);
				
				listaPeca1 += "Pe�a: " + m.getPeca() + "\n";
			}
			if(opcao.equals("2")){
				JOptionPane.showMessageDialog(null,"Lista de Pe�as Montadas: \n" + listaPeca1);
			}
			if(opcao.equals("3")){
				
				if (pilha.isEmpty()){
					JOptionPane.showMessageDialog(null, "Todas as Pe�as ja Foram Removidas!");
					listaPeca1 = "";
					listaPeca2 = "";
				}
				else{
					Montagem m = pilha.pop();
					listaPeca2 += "Pe�a: " + m.getPeca() + "\n";
					JOptionPane.showMessageDialog(null,"Pe�as removidas \n" + listaPeca2);
				}
			}
		}while(!opcao.equals("4"));
	}
}
