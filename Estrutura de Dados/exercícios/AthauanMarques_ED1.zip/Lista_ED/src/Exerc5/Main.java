package Exerc5;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import Exerc5.Supermercado;

public class Main {

	public static void main(String[] args) {
		String produto;
		int codigo;
		int quantidade;
		float valor;
		int opcao;
		List<Supermercado> lista = new ArrayList<Supermercado>();
		
		do{
			Supermercado s = new Supermercado();
			produto = JOptionPane.showInputDialog("Informe o Nome do produto: ");
			codigo = Integer.parseInt(JOptionPane.showInputDialog("Informe o codigo do Produto: "));
			quantidade = Integer.parseInt(JOptionPane.showInputDialog("Informe a quantidade de Produtos: "));
			valor = Float.parseFloat(JOptionPane.showInputDialog("Informe o valor da unidade: "));
			s.setProduto(produto);
			s.setCodigo(codigo);
			s.setQuantidade(quantidade);
			s.setValor(valor);
			lista.add(s);
			opcao = Integer.parseInt(JOptionPane.showInputDialog("Deseja inserir mais Produtos \n1.Sim \n2.N�o"));
			
		}while(opcao == 1);
		
		int contador = 0;
		String listaProd = "";
		int totalProd = 0;
		float totalValor = 0;
		
		for(int i = 0; i < lista.size(); i++){
			Supermercado s = lista.get(i);
			contador += 1;
			listaProd += contador + "� " + "Produto: " + s.getProduto() + "\n"
					+ "Codigo: " + s.getCodigo() + " Quantidade: " + s.getQuantidade() + " Valor: " + s.getValor() + "\n";
			
			totalProd += s.getQuantidade();
			totalValor += s.getQuantidade() * s.getValor();
			
		}
		JOptionPane.showMessageDialog(null,"Lista de Produtos: \n" + listaProd + "\n\nTotal de Produtos: " 
											+ totalProd + "\nValor total a pagar: " + totalValor);
	}

}
