package Exerc7;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import Exerc7.Produtos;

public class Main {

	public static void main(String[] args) {
		String produto, opcao;
		List<Produtos> lista = new ArrayList<Produtos>();
		
		do{
			opcao = JOptionPane.showInputDialog("1. Inserir \n"
											  + "2. Remover \n"
											  + "3. Sair");
			if (opcao.equals("1")) {
				
					Produtos p = new Produtos();
					produto = JOptionPane.showInputDialog("Informe o Nome do produto: ");
					p.setProduto(produto);
					lista.add(p);
				
			} else if (opcao.equals("2")){
				
				if (lista.isEmpty()) {
					JOptionPane.showMessageDialog(null, "N�o h� Produtos cadastrados");
				}
				else{
					String tabela = "CODIGO | PRODUTO \n";
					for (int i = 0; i < lista.size(); i++) {
						Produtos p = lista.get(i);
						tabela += i + " | " + p.getProduto() + "\n";
					}
					int indice = Integer.parseInt(JOptionPane.showInputDialog("Informa o codigo do Produto "
																			+ "que deseja remover.\n" + tabela));
					lista.remove(indice);
					
					tabela = "CODIGO | PRODUTO \n";
					for (int i = 0; i < lista.size(); i++) {
						Produtos p = lista.get(i);
						tabela += i + " | " + p.getProduto() + "\n";
					}
					JOptionPane.showMessageDialog(null, tabela);
				}
			}
		}while (!opcao.equals("3"));
	}
}
