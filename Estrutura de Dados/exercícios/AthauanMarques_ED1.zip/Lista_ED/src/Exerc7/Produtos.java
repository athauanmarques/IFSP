package Exerc7;

public class Produtos {
	
	String produto;
	
	public String getProduto() {
		return produto;
	}
	public void setProduto(String produto) {
		this.produto = produto;
	}
	
}
