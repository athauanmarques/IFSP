package Exerc4;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import Exerc4.Crescente;

public class Main {

	public static void main(String[] args) {
		
		int numero, opcao;
		List<Crescente> lista = new ArrayList<Crescente>();
		
		do{
			Crescente c = new Crescente();
			numero = Integer.parseInt(JOptionPane.showInputDialog("Informe um numero inteiro: "));
			c.setNumero(numero);
			lista.add(c);
			opcao = Integer.parseInt(JOptionPane.showInputDialog("Deseja inserir mais numeros \n1.Sim \n2.N�o"));
			
		}while(opcao == 1);
		
		int contador = 0;
		int contador2 = 0;
		int cres = 0;
		String listaNum = "";
		
		for(int i = 0; i < lista.size(); i++){
			Crescente c = lista.get(i);
			contador += 1;
			
			listaNum += contador + "� " + "Numero: " + c.getNumero() + "\n";
			if (c.getNumero() > cres) {
				cres = c.getNumero();
				contador2 += 1;
			}
		}
		
		if (contador2 == contador) {
			JOptionPane.showMessageDialog(null,"Lista de Numeros Informados: \n" + listaNum + 
					   						   "\nA lista � crescente!");
		} else {
			JOptionPane.showMessageDialog(null,"Lista de Numeros Informados: \n" + listaNum + 
					   						   "\nA lista n�o � crescente!");
		}
	}
}
