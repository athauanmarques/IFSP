package Exerc1;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import Exerc2.Numeros;

public class Main {

	public static void main(String[] args) {
		
		int numero, opcao;
		List<Numeros> lista = new ArrayList<Numeros>();
		
		do{
			Numeros n = new Numeros();
			numero = Integer.parseInt(JOptionPane.showInputDialog("Informe um numero inteiro: "));
			n.setNumero(numero);
			lista.add(n);
			opcao = Integer.parseInt(JOptionPane.showInputDialog("Deseja inserir mais numeros \n1.Sim \n2.N�o"));
			
		}while(opcao == 1);
		
		int maiorNum = 0;
		
		for(int i = 0; i < lista.size(); i++){
			Numeros n = lista.get(i);
									
			if (n.getNumero() > maiorNum) {
				maiorNum = n.getNumero();
			}
		}
		JOptionPane.showMessageDialog(null,"O Maior numero �: " + maiorNum);
	}
}
