package Exerc3;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import Exerc3.Media;

public class Main {

	public static void main(String[] args) {
		int numero, opcao;
		List<Media> lista = new ArrayList<Media>();
		
		do{
			Media m = new Media();
			numero = Integer.parseInt(JOptionPane.showInputDialog("Informe um numero inteiro: "));
			m.setNumero(numero);
			lista.add(m);
			opcao = Integer.parseInt(JOptionPane.showInputDialog("Deseja inserir mais numeros \n1.Sim \n2.N�o"));
			
		}while(opcao == 1);
		
		int total = 0;
		int mediaNum = 0;
		int contador = 0;
		String listaNum = "";
		
		for(int i = 0; i < lista.size(); i++){
			Media m = lista.get(i);
			total += m.getNumero();
			contador += 1;
			
			listaNum += contador + "� " + "Numero: " + m.getNumero() + "\n";
		}
		
		mediaNum = total / contador;
		JOptionPane.showMessageDialog(null,"Lista de Numeros Informados: \n" + listaNum + 
										   "\nA m�dia dos numeros informados �: " + mediaNum);
	}

}
