package Exerc6;

import Exerc6.Farmacia;

import java.util.ArrayDeque;
import java.util.Queue;

import javax.swing.JOptionPane;

public class Main {

	public static void main(String[] args) {
		int senha = 0, opcao;
		Queue<Farmacia> fila = new ArrayDeque<Farmacia>();
		
		do{
			opcao = Integer.parseInt(JOptionPane.showInputDialog("\n1.Retirar Senha \n2.Chamar proxima senha \n3.Sair"));
			if(opcao == 1){
				Farmacia f = new Farmacia();
				senha += 1;
				f.setSenha(senha);
				fila.add(f);
				JOptionPane.showMessageDialog(null, "Sua senha �: " + f.getSenha());
			}
			if(opcao == 2){
				if(!fila.isEmpty()){
					Farmacia f = fila.remove();
					JOptionPane.showMessageDialog(null, "Em Atendimento: " + f.getSenha());
				}
				else{
					JOptionPane.showMessageDialog(null, "Sem pessoas para serem atendidas!");
				}
			}
		}while(opcao != 3);
	}
}
