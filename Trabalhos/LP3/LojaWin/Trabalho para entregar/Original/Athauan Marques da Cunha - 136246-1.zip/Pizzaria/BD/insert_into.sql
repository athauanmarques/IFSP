
--
-- Tabela de usuario
--

insert into pizzaria.usuarios(idUsuarios,usuario, funcao, senha, tipoAcesso, foto) values (2,'Bruna Campos','CEO',123123,'Administrador','89465');
insert into pizzaria.usuarios(idUsuarios,usuario, funcao, senha, tipoAcesso, foto) values (3,'Dollynho: Sabor brasileiro ','Ajudante Geral',321321,'Comum');


--
-- Tabela de Clientes
--

insert into pizzaria.clientes(nome, endereco, telefone, cidade, uf, referencias) values ('Bruna de Carvalho','Rua General Raul Ferreira, 857','8877-7571','Bragança Paulista','SP','Centro');
insert into pizzaria.clientes(nome, endereco, telefone, cidade, uf, referencias) values ('Caio Castro Carvalho','Avenida Liberdade','2036-8741','Atibaia','SP','Escola');
insert into pizzaria.clientes(nome, endereco, telefone, cidade, uf, referencias) values ('Joana Alvez Souza  ','Avenida Paz e Luta','875-3001','Campinas','SP','São José');
insert into pizzaria.clientes(nome, endereco, telefone, cidade, uf, referencias) values ('Jason Mike','Rua do sabão','8700-0025','Campo Grande','RS','Mar Azul');
insert into pizzaria.clientes(nome, endereco, telefone, cidade, uf, referencias) values ('Ana Cristina de Jesus','Rua Jorge Poeta','1025-9687','Londres','BA','Em casa');
insert into pizzaria.clientes(nome, endereco, telefone, cidade, uf, referencias) values ('Usura Hanna Minaki','Avenida ocidental','2020-3685','Bragança','RS','Centro');

--
-- Tabela de preço
--


insert into pizzaria.pizzas(sabor,informacoes,precoG,precoM,precoP) values ('Alho e Óleo','alhoorégano','40.00','25.00','12.00');
insert into pizzaria.pizzas(sabor,informacoes,precoG,precoM,precoP) values ('Alicci Molho', 'mussarela, alicci e orégano.','40.00','25.00','12.00');


--
-- Tabela de Pedido
--

insert into pizzaria.pedidos(dataPedido, custoTotal, caixa, quantidade,idClientes) values ('1995-01-02','102.52','1.200','23',1);
insert into pizzaria.pedidos(dataPedido, custoTotal, caixa, quantidade,idClientes) values ('2015-02-10','40.00','40.00','1',2);
insert into pizzaria.pedidos(dataPedido, custoTotal, caixa, quantidade,idClientes) values ('2015-10-08','25.00','25.00','1',2);
