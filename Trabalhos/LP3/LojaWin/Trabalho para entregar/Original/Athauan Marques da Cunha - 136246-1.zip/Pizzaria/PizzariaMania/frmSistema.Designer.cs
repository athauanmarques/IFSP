﻿namespace PizzariaMania
{
    partial class frmSistema
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSistema));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            this.mtpGerenciador = new MetroFramework.Controls.MetroTabControl();
            this.tpClientes = new MetroFramework.Controls.MetroTabPage();
            this.lblPermissao = new System.Windows.Forms.Label();
            this.bntFiltrar = new MetroFramework.Controls.MetroButton();
            this.lblFiltrarCadastro = new MetroFramework.Controls.MetroLabel();
            this.txtFiltar = new MetroFramework.Controls.MetroTextBox();
            this.tbsClientes = new MetroFramework.Controls.MetroTabControl();
            this.mtpAdicionar = new MetroFramework.Controls.MetroTabPage();
            this.bntAdicionarCliente = new MetroFramework.Controls.MetroTile();
            this.bntAdiLimparCliente = new MetroFramework.Controls.MetroButton();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.cbbAdiUFCliente = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.txtAdiCidadeCliente = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.txtAdiTelefoneCliente = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.txtAdiReferenciasCliente = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.txtAdiEnderecoCliente = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.txtAdiNomeCliente = new MetroFramework.Controls.MetroTextBox();
            this.mtpAlterar = new MetroFramework.Controls.MetroTabPage();
            this.lblIdCliente = new MetroFramework.Controls.MetroLabel();
            this.bntAlteraCliente = new MetroFramework.Controls.MetroTile();
            this.bntAltLimparCliente = new MetroFramework.Controls.MetroButton();
            this.cbbAltUfCliente = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel10 = new MetroFramework.Controls.MetroLabel();
            this.txtAltCidadeCliente = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel11 = new MetroFramework.Controls.MetroLabel();
            this.txtAltTelefoneCliente = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel12 = new MetroFramework.Controls.MetroLabel();
            this.txtAltReferenciasCliente = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel13 = new MetroFramework.Controls.MetroLabel();
            this.txtAltEnderecoCliente = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel14 = new MetroFramework.Controls.MetroLabel();
            this.txtAltNomeCliente = new MetroFramework.Controls.MetroTextBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.mtpRemover = new MetroFramework.Controls.MetroTabPage();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.txtExcNomeCliente = new MetroFramework.Controls.MetroTextBox();
            this.bntExluirCliente = new MetroFramework.Controls.MetroTile();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.metroLabel20 = new MetroFramework.Controls.MetroLabel();
            this.txtExcIdCliente = new MetroFramework.Controls.MetroTextBox();
            this.dgvClientes = new MetroFramework.Controls.MetroGrid();
            this.tpPedidos = new MetroFramework.Controls.MetroTabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.bntCancelarPedidos = new MetroFramework.Controls.MetroTile();
            this.bntAdicionarPedido = new MetroFramework.Controls.MetroTile();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.metroLabel16 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel18 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel22 = new MetroFramework.Controls.MetroLabel();
            this.txtCaixa = new MetroFramework.Controls.MetroTextBox();
            this.txtCustoTotal = new MetroFramework.Controls.MetroTextBox();
            this.gbxTabela = new System.Windows.Forms.GroupBox();
            this.bntAtualizaPizza = new MetroFramework.Controls.MetroButton();
            this.bntEditar = new MetroFramework.Controls.MetroButton();
            this.metroLabel25 = new MetroFramework.Controls.MetroLabel();
            this.dgvPizzas = new MetroFramework.Controls.MetroGrid();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.lblTesteListBox = new System.Windows.Forms.Label();
            this.txtQuantidade = new MetroFramework.Controls.MetroTextBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.rbtGrandeP = new System.Windows.Forms.RadioButton();
            this.rbtMediaP = new System.Windows.Forms.RadioButton();
            this.rbtPequenaP = new System.Windows.Forms.RadioButton();
            this.bntRemoverItens = new MetroFramework.Controls.MetroButton();
            this.lbxItens = new System.Windows.Forms.ListBox();
            this.bntLimparItens = new MetroFramework.Controls.MetroButton();
            this.bntIntesAdicionar = new MetroFramework.Controls.MetroTile();
            this.txtInfoPedido = new MetroFramework.Controls.MetroTextBox();
            this.txtSaborPedido = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel24 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel23 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel19 = new MetroFramework.Controls.MetroLabel();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.lblIDClienteTs = new System.Windows.Forms.Label();
            this.txtNomePedido = new MetroFramework.Controls.MetroTextBox();
            this.bntProcuraCliente = new MetroFramework.Controls.MetroButton();
            this.txtTelefonePedido = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel17 = new MetroFramework.Controls.MetroLabel();
            this.txtDataPedido = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel15 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel21 = new MetroFramework.Controls.MetroLabel();
            this.tbRelatorios = new MetroFramework.Controls.MetroTabPage();
            this.tbMenuRelatorio = new DevComponents.DotNetBar.TabControl();
            this.tabControlPanel6 = new DevComponents.DotNetBar.TabControlPanel();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.dgvPizzas2 = new MetroFramework.Controls.MetroGrid();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.metroLabel29 = new MetroFramework.Controls.MetroLabel();
            this.bntPizzasEditar = new MetroFramework.Controls.MetroTile();
            this.cbPizzaEditar = new MetroFramework.Controls.MetroComboBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.htmlLabel2 = new MetroFramework.Drawing.Html.HtmlLabel();
            this.tbTabelaPizza = new DevComponents.DotNetBar.TabItem(this.components);
            this.tabControlPanel5 = new DevComponents.DotNetBar.TabControlPanel();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.dgvPedidos = new MetroFramework.Controls.MetroGrid();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.metroLabel28 = new MetroFramework.Controls.MetroLabel();
            this.bntExibirConsulta = new MetroFramework.Controls.MetroTile();
            this.cbConsultas = new MetroFramework.Controls.MetroComboBox();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.bntImprimir = new MetroFramework.Controls.MetroButton();
            this.bntVisualizaImp = new MetroFramework.Controls.MetroButton();
            this.txtPedidos = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.bntProcurarPedido = new MetroFramework.Controls.MetroButton();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.radialMenu1 = new DevComponents.DotNetBar.RadialMenu();
            this.itsAdicionar = new DevComponents.DotNetBar.RadialMenuItem();
            this.itsAlterar = new DevComponents.DotNetBar.RadialMenuItem();
            this.itsRemover = new DevComponents.DotNetBar.RadialMenuItem();
            this.itsCal = new DevComponents.DotNetBar.RadialMenuItem();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.metroButton2 = new MetroFramework.Controls.MetroButton();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.txtProPedidos = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel26 = new MetroFramework.Controls.MetroLabel();
            this.bntProPedidos = new MetroFramework.Controls.MetroButton();
            this.htmlLabel1 = new MetroFramework.Drawing.Html.HtmlLabel();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.tbPedidosRealizados = new DevComponents.DotNetBar.TabItem(this.components);
            this.tabControlPanel7 = new DevComponents.DotNetBar.TabControlPanel();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.bntRemover = new MetroFramework.Controls.MetroTile();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.lblAvisoRegistro = new System.Windows.Forms.Label();
            this.dgvAcesso = new MetroFramework.Controls.MetroGrid();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.htmlLabel3 = new MetroFramework.Drawing.Html.HtmlLabel();
            this.tbRegistro = new DevComponents.DotNetBar.TabItem(this.components);
            this.metroDateTime1 = new MetroFramework.Controls.MetroDateTime();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tabControl1 = new DevComponents.DotNetBar.TabControl();
            this.tabControlPanel1 = new DevComponents.DotNetBar.TabControlPanel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.bntOpAtualizar = new MetroFramework.Controls.MetroButton();
            this.bntOpSair = new MetroFramework.Controls.MetroButton();
            this.bntOpLimpar = new MetroFramework.Controls.MetroButton();
            this.bntOpFiltrar = new MetroFramework.Controls.MetroButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.metroButton3 = new MetroFramework.Controls.MetroButton();
            this.bntVerPerfil = new MetroFramework.Controls.MetroButton();
            this.bntPedidos = new MetroFramework.Controls.MetroButton();
            this.bntRelatorios = new MetroFramework.Controls.MetroButton();
            this.tabItem1 = new DevComponents.DotNetBar.TabItem(this.components);
            this.tabControlPanel2 = new DevComponents.DotNetBar.TabControlPanel();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.bntPedidosRealizados = new MetroFramework.Controls.MetroButton();
            this.bntRelatorioPizza = new MetroFramework.Controls.MetroButton();
            this.bntRegistro = new MetroFramework.Controls.MetroButton();
            this.tabItem2 = new DevComponents.DotNetBar.TabItem(this.components);
            this.tabControlPanel3 = new DevComponents.DotNetBar.TabControlPanel();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.frmSobre = new MetroFramework.Controls.MetroButton();
            this.bntAjuda = new MetroFramework.Controls.MetroButton();
            this.bntCaculadora = new MetroFramework.Controls.MetroButton();
            this.tabItem3 = new DevComponents.DotNetBar.TabItem(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.lblMensagem = new MetroFramework.Controls.MetroLabel();
            this.lblStatus = new MetroFramework.Controls.MetroTile();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.lblTipoAcesso = new MetroFramework.Controls.MetroLabel();
            this.lblUsuario = new MetroFramework.Controls.MetroLabel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.printDlg = new System.Windows.Forms.PrintDialog();
            this.printDoc = new System.Drawing.Printing.PrintDocument();
            this.printPreview = new System.Windows.Forms.PrintPreviewDialog();
            this.mtpGerenciador.SuspendLayout();
            this.tpClientes.SuspendLayout();
            this.tbsClientes.SuspendLayout();
            this.mtpAdicionar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.mtpAlterar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.mtpRemover.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvClientes)).BeginInit();
            this.tpPedidos.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.gbxTabela.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPizzas)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tbRelatorios.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbMenuRelatorio)).BeginInit();
            this.tbMenuRelatorio.SuspendLayout();
            this.tabControlPanel6.SuspendLayout();
            this.groupBox15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPizzas2)).BeginInit();
            this.groupBox16.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            this.tabControlPanel5.SuspendLayout();
            this.groupBox12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPedidos)).BeginInit();
            this.groupBox11.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            this.groupBox9.SuspendLayout();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            this.tabControlPanel7.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.groupBox17.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAcesso)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tabControl1)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabControlPanel1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabControlPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.tabControlPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.groupBox10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // mtpGerenciador
            // 
            this.mtpGerenciador.Controls.Add(this.tpClientes);
            this.mtpGerenciador.Controls.Add(this.tpPedidos);
            this.mtpGerenciador.Controls.Add(this.tbRelatorios);
            this.mtpGerenciador.Location = new System.Drawing.Point(304, 64);
            this.mtpGerenciador.Name = "mtpGerenciador";
            this.mtpGerenciador.SelectedIndex = 2;
            this.mtpGerenciador.Size = new System.Drawing.Size(1022, 595);
            this.mtpGerenciador.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.mtpGerenciador.Style = MetroFramework.MetroColorStyle.Red;
            this.mtpGerenciador.TabIndex = 2;
            this.mtpGerenciador.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.mtpGerenciador.UseSelectable = true;
            // 
            // tpClientes
            // 
            this.tpClientes.Controls.Add(this.lblPermissao);
            this.tpClientes.Controls.Add(this.bntFiltrar);
            this.tpClientes.Controls.Add(this.lblFiltrarCadastro);
            this.tpClientes.Controls.Add(this.txtFiltar);
            this.tpClientes.Controls.Add(this.tbsClientes);
            this.tpClientes.Controls.Add(this.dgvClientes);
            this.tpClientes.HorizontalScrollbarBarColor = true;
            this.tpClientes.HorizontalScrollbarHighlightOnWheel = false;
            this.tpClientes.HorizontalScrollbarSize = 10;
            this.tpClientes.Location = new System.Drawing.Point(4, 38);
            this.tpClientes.Name = "tpClientes";
            this.tpClientes.Size = new System.Drawing.Size(1014, 553);
            this.tpClientes.TabIndex = 0;
            this.tpClientes.Text = "Clientes";
            this.tpClientes.VerticalScrollbarBarColor = true;
            this.tpClientes.VerticalScrollbarHighlightOnWheel = false;
            this.tpClientes.VerticalScrollbarSize = 10;
            this.tpClientes.Click += new System.EventHandler(this.tpClientes_Click);
            // 
            // lblPermissao
            // 
            this.lblPermissao.AutoSize = true;
            this.lblPermissao.BackColor = System.Drawing.Color.Transparent;
            this.lblPermissao.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPermissao.Location = new System.Drawing.Point(3, 128);
            this.lblPermissao.Name = "lblPermissao";
            this.lblPermissao.Size = new System.Drawing.Size(993, 78);
            this.lblPermissao.TabIndex = 24;
            this.lblPermissao.Text = "                                   Acesso Negado\r\nVocê não tem permissão de utili" +
                "za esta função de cadastro.";
            this.lblPermissao.Click += new System.EventHandler(this.lblPermissao_Click);
            // 
            // bntFiltrar
            // 
            this.bntFiltrar.Location = new System.Drawing.Point(621, 510);
            this.bntFiltrar.Name = "bntFiltrar";
            this.bntFiltrar.Size = new System.Drawing.Size(117, 23);
            this.bntFiltrar.TabIndex = 9;
            this.bntFiltrar.Text = "Filtrar";
            this.bntFiltrar.UseSelectable = true;
            this.bntFiltrar.Click += new System.EventHandler(this.bntFiltrar_Click);
            // 
            // lblFiltrarCadastro
            // 
            this.lblFiltrarCadastro.AutoSize = true;
            this.lblFiltrarCadastro.Location = new System.Drawing.Point(285, 510);
            this.lblFiltrarCadastro.Name = "lblFiltrarCadastro";
            this.lblFiltrarCadastro.Size = new System.Drawing.Size(43, 19);
            this.lblFiltrarCadastro.TabIndex = 5;
            this.lblFiltrarCadastro.Text = "Filtrar";
            // 
            // txtFiltar
            // 
            this.txtFiltar.Lines = new string[0];
            this.txtFiltar.Location = new System.Drawing.Point(334, 510);
            this.txtFiltar.MaxLength = 32767;
            this.txtFiltar.Name = "txtFiltar";
            this.txtFiltar.PasswordChar = '\0';
            this.txtFiltar.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtFiltar.SelectedText = "";
            this.txtFiltar.Size = new System.Drawing.Size(272, 23);
            this.txtFiltar.TabIndex = 8;
            this.txtFiltar.UseSelectable = true;
            // 
            // tbsClientes
            // 
            this.tbsClientes.Alignment = System.Windows.Forms.TabAlignment.Bottom;
            this.tbsClientes.Controls.Add(this.mtpAdicionar);
            this.tbsClientes.Controls.Add(this.mtpAlterar);
            this.tbsClientes.Controls.Add(this.mtpRemover);
            this.tbsClientes.Location = new System.Drawing.Point(209, 229);
            this.tbsClientes.Name = "tbsClientes";
            this.tbsClientes.SelectedIndex = 0;
            this.tbsClientes.Size = new System.Drawing.Size(606, 256);
            this.tbsClientes.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tbsClientes.Style = MetroFramework.MetroColorStyle.Red;
            this.tbsClientes.TabIndex = 3;
            this.tbsClientes.UseSelectable = true;
            // 
            // mtpAdicionar
            // 
            this.mtpAdicionar.Controls.Add(this.bntAdicionarCliente);
            this.mtpAdicionar.Controls.Add(this.bntAdiLimparCliente);
            this.mtpAdicionar.Controls.Add(this.pictureBox2);
            this.mtpAdicionar.Controls.Add(this.cbbAdiUFCliente);
            this.mtpAdicionar.Controls.Add(this.metroLabel4);
            this.mtpAdicionar.Controls.Add(this.metroLabel5);
            this.mtpAdicionar.Controls.Add(this.txtAdiCidadeCliente);
            this.mtpAdicionar.Controls.Add(this.metroLabel6);
            this.mtpAdicionar.Controls.Add(this.txtAdiTelefoneCliente);
            this.mtpAdicionar.Controls.Add(this.metroLabel3);
            this.mtpAdicionar.Controls.Add(this.txtAdiReferenciasCliente);
            this.mtpAdicionar.Controls.Add(this.metroLabel2);
            this.mtpAdicionar.Controls.Add(this.txtAdiEnderecoCliente);
            this.mtpAdicionar.Controls.Add(this.metroLabel1);
            this.mtpAdicionar.Controls.Add(this.txtAdiNomeCliente);
            this.mtpAdicionar.HorizontalScrollbarBarColor = true;
            this.mtpAdicionar.HorizontalScrollbarHighlightOnWheel = false;
            this.mtpAdicionar.HorizontalScrollbarSize = 10;
            this.mtpAdicionar.Location = new System.Drawing.Point(4, 4);
            this.mtpAdicionar.Name = "mtpAdicionar";
            this.mtpAdicionar.Size = new System.Drawing.Size(598, 214);
            this.mtpAdicionar.TabIndex = 0;
            this.mtpAdicionar.Text = "Adicionar";
            this.mtpAdicionar.VerticalScrollbarBarColor = true;
            this.mtpAdicionar.VerticalScrollbarHighlightOnWheel = false;
            this.mtpAdicionar.VerticalScrollbarSize = 10;
            // 
            // bntAdicionarCliente
            // 
            this.bntAdicionarCliente.ActiveControl = null;
            this.bntAdicionarCliente.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bntAdicionarCliente.Location = new System.Drawing.Point(422, 104);
            this.bntAdicionarCliente.Name = "bntAdicionarCliente";
            this.bntAdicionarCliente.Size = new System.Drawing.Size(103, 104);
            this.bntAdicionarCliente.Style = MetroFramework.MetroColorStyle.Red;
            this.bntAdicionarCliente.TabIndex = 6;
            this.bntAdicionarCliente.Text = "Adicionar";
            this.bntAdicionarCliente.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bntAdicionarCliente.Theme = MetroFramework.MetroThemeStyle.Light;
            this.bntAdicionarCliente.UseSelectable = true;
            this.bntAdicionarCliente.Click += new System.EventHandler(this.bntAdicionarCliente_Click);
            // 
            // bntAdiLimparCliente
            // 
            this.bntAdiLimparCliente.Location = new System.Drawing.Point(422, 64);
            this.bntAdiLimparCliente.Name = "bntAdiLimparCliente";
            this.bntAdiLimparCliente.Size = new System.Drawing.Size(103, 34);
            this.bntAdiLimparCliente.TabIndex = 7;
            this.bntAdiLimparCliente.Text = "Limpar";
            this.bntAdiLimparCliente.UseSelectable = true;
            this.bntAdiLimparCliente.Click += new System.EventHandler(this.bntAdiLimparCliente_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(41, 53);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(126, 128);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 15;
            this.pictureBox2.TabStop = false;
            // 
            // cbbAdiUFCliente
            // 
            this.cbbAdiUFCliente.FormattingEnabled = true;
            this.cbbAdiUFCliente.ItemHeight = 23;
            this.cbbAdiUFCliente.Items.AddRange(new object[] {
            "AC",
            "AL",
            "AP",
            "AM",
            "BA",
            "CE",
            "ES",
            "GO",
            "MA",
            "MT",
            "MS",
            "MG",
            "PA",
            "PB",
            "PR",
            "PE",
            "PI",
            "RJ",
            "RN",
            "RS",
            "RO",
            "RR",
            "SC",
            "SP",
            "TO"});
            this.cbbAdiUFCliente.Location = new System.Drawing.Point(254, 179);
            this.cbbAdiUFCliente.Name = "cbbAdiUFCliente";
            this.cbbAdiUFCliente.Size = new System.Drawing.Size(148, 29);
            this.cbbAdiUFCliente.Style = MetroFramework.MetroColorStyle.Red;
            this.cbbAdiUFCliente.TabIndex = 5;
            this.cbbAdiUFCliente.UseSelectable = true;
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(197, 189);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(25, 19);
            this.metroLabel4.TabIndex = 13;
            this.metroLabel4.Text = "UF";
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(176, 97);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(54, 19);
            this.metroLabel5.TabIndex = 11;
            this.metroLabel5.Text = "Cidade:";
            // 
            // txtAdiCidadeCliente
            // 
            this.txtAdiCidadeCliente.Lines = new string[0];
            this.txtAdiCidadeCliente.Location = new System.Drawing.Point(254, 93);
            this.txtAdiCidadeCliente.MaxLength = 32767;
            this.txtAdiCidadeCliente.Name = "txtAdiCidadeCliente";
            this.txtAdiCidadeCliente.PasswordChar = '\0';
            this.txtAdiCidadeCliente.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtAdiCidadeCliente.SelectedText = "";
            this.txtAdiCidadeCliente.Size = new System.Drawing.Size(148, 23);
            this.txtAdiCidadeCliente.TabIndex = 2;
            this.txtAdiCidadeCliente.UseSelectable = true;
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(173, 126);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(57, 19);
            this.metroLabel6.TabIndex = 9;
            this.metroLabel6.Text = "Telefone";
            // 
            // txtAdiTelefoneCliente
            // 
            this.txtAdiTelefoneCliente.Lines = new string[0];
            this.txtAdiTelefoneCliente.Location = new System.Drawing.Point(254, 122);
            this.txtAdiTelefoneCliente.MaxLength = 32767;
            this.txtAdiTelefoneCliente.Name = "txtAdiTelefoneCliente";
            this.txtAdiTelefoneCliente.PasswordChar = '\0';
            this.txtAdiTelefoneCliente.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtAdiTelefoneCliente.SelectedText = "";
            this.txtAdiTelefoneCliente.Size = new System.Drawing.Size(148, 23);
            this.txtAdiTelefoneCliente.TabIndex = 3;
            this.txtAdiTelefoneCliente.UseSelectable = true;
            this.txtAdiTelefoneCliente.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAdiTelefoneCliente_KeyPress);
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(173, 68);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(75, 19);
            this.metroLabel3.TabIndex = 7;
            this.metroLabel3.Text = "Referências";
            // 
            // txtAdiReferenciasCliente
            // 
            this.txtAdiReferenciasCliente.Lines = new string[0];
            this.txtAdiReferenciasCliente.Location = new System.Drawing.Point(254, 64);
            this.txtAdiReferenciasCliente.MaxLength = 32767;
            this.txtAdiReferenciasCliente.Name = "txtAdiReferenciasCliente";
            this.txtAdiReferenciasCliente.PasswordChar = '\0';
            this.txtAdiReferenciasCliente.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtAdiReferenciasCliente.SelectedText = "";
            this.txtAdiReferenciasCliente.Size = new System.Drawing.Size(148, 23);
            this.txtAdiReferenciasCliente.TabIndex = 1;
            this.txtAdiReferenciasCliente.UseSelectable = true;
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(176, 154);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(64, 19);
            this.metroLabel2.TabIndex = 5;
            this.metroLabel2.Text = "Endereço";
            // 
            // txtAdiEnderecoCliente
            // 
            this.txtAdiEnderecoCliente.Lines = new string[0];
            this.txtAdiEnderecoCliente.Location = new System.Drawing.Point(254, 150);
            this.txtAdiEnderecoCliente.MaxLength = 32767;
            this.txtAdiEnderecoCliente.Name = "txtAdiEnderecoCliente";
            this.txtAdiEnderecoCliente.PasswordChar = '\0';
            this.txtAdiEnderecoCliente.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtAdiEnderecoCliente.SelectedText = "";
            this.txtAdiEnderecoCliente.Size = new System.Drawing.Size(148, 23);
            this.txtAdiEnderecoCliente.TabIndex = 4;
            this.txtAdiEnderecoCliente.UseSelectable = true;
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(176, 39);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(46, 19);
            this.metroLabel1.TabIndex = 3;
            this.metroLabel1.Text = "Nome";
            // 
            // txtAdiNomeCliente
            // 
            this.txtAdiNomeCliente.Lines = new string[0];
            this.txtAdiNomeCliente.Location = new System.Drawing.Point(254, 35);
            this.txtAdiNomeCliente.MaxLength = 32767;
            this.txtAdiNomeCliente.Name = "txtAdiNomeCliente";
            this.txtAdiNomeCliente.PasswordChar = '\0';
            this.txtAdiNomeCliente.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtAdiNomeCliente.SelectedText = "";
            this.txtAdiNomeCliente.Size = new System.Drawing.Size(271, 23);
            this.txtAdiNomeCliente.TabIndex = 0;
            this.txtAdiNomeCliente.UseSelectable = true;
            // 
            // mtpAlterar
            // 
            this.mtpAlterar.Controls.Add(this.lblIdCliente);
            this.mtpAlterar.Controls.Add(this.bntAlteraCliente);
            this.mtpAlterar.Controls.Add(this.bntAltLimparCliente);
            this.mtpAlterar.Controls.Add(this.cbbAltUfCliente);
            this.mtpAlterar.Controls.Add(this.metroLabel9);
            this.mtpAlterar.Controls.Add(this.metroLabel10);
            this.mtpAlterar.Controls.Add(this.txtAltCidadeCliente);
            this.mtpAlterar.Controls.Add(this.metroLabel11);
            this.mtpAlterar.Controls.Add(this.txtAltTelefoneCliente);
            this.mtpAlterar.Controls.Add(this.metroLabel12);
            this.mtpAlterar.Controls.Add(this.txtAltReferenciasCliente);
            this.mtpAlterar.Controls.Add(this.metroLabel13);
            this.mtpAlterar.Controls.Add(this.txtAltEnderecoCliente);
            this.mtpAlterar.Controls.Add(this.metroLabel14);
            this.mtpAlterar.Controls.Add(this.txtAltNomeCliente);
            this.mtpAlterar.Controls.Add(this.pictureBox4);
            this.mtpAlterar.HorizontalScrollbarBarColor = true;
            this.mtpAlterar.HorizontalScrollbarHighlightOnWheel = false;
            this.mtpAlterar.HorizontalScrollbarSize = 10;
            this.mtpAlterar.Location = new System.Drawing.Point(4, 4);
            this.mtpAlterar.Name = "mtpAlterar";
            this.mtpAlterar.Size = new System.Drawing.Size(598, 214);
            this.mtpAlterar.TabIndex = 1;
            this.mtpAlterar.Text = "Alterar";
            this.mtpAlterar.VerticalScrollbarBarColor = true;
            this.mtpAlterar.VerticalScrollbarHighlightOnWheel = false;
            this.mtpAlterar.VerticalScrollbarSize = 10;
            // 
            // lblIdCliente
            // 
            this.lblIdCliente.AutoSize = true;
            this.lblIdCliente.Location = new System.Drawing.Point(72, 35);
            this.lblIdCliente.Name = "lblIdCliente";
            this.lblIdCliente.Size = new System.Drawing.Size(90, 19);
            this.lblIdCliente.TabIndex = 33;
            this.lblIdCliente.Text = "metroLabel27";
            this.lblIdCliente.Visible = false;
            // 
            // bntAlteraCliente
            // 
            this.bntAlteraCliente.ActiveControl = null;
            this.bntAlteraCliente.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bntAlteraCliente.Location = new System.Drawing.Point(424, 108);
            this.bntAlteraCliente.Name = "bntAlteraCliente";
            this.bntAlteraCliente.Size = new System.Drawing.Size(117, 104);
            this.bntAlteraCliente.Style = MetroFramework.MetroColorStyle.Red;
            this.bntAlteraCliente.TabIndex = 32;
            this.bntAlteraCliente.Text = "Alterar";
            this.bntAlteraCliente.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bntAlteraCliente.Theme = MetroFramework.MetroThemeStyle.Light;
            this.bntAlteraCliente.UseSelectable = true;
            this.bntAlteraCliente.Click += new System.EventHandler(this.bntAlteraCliente_Click);
            // 
            // bntAltLimparCliente
            // 
            this.bntAltLimparCliente.Location = new System.Drawing.Point(424, 68);
            this.bntAltLimparCliente.Name = "bntAltLimparCliente";
            this.bntAltLimparCliente.Size = new System.Drawing.Size(117, 34);
            this.bntAltLimparCliente.TabIndex = 31;
            this.bntAltLimparCliente.Text = "Limpar";
            this.bntAltLimparCliente.UseSelectable = true;
            this.bntAltLimparCliente.Click += new System.EventHandler(this.bntAltLimparCliente_Click);
            // 
            // cbbAltUfCliente
            // 
            this.cbbAltUfCliente.FormattingEnabled = true;
            this.cbbAltUfCliente.ItemHeight = 23;
            this.cbbAltUfCliente.Items.AddRange(new object[] {
            "AC",
            "AL",
            "AP",
            "AM",
            "BA",
            "CE",
            "ES",
            "GO",
            "MA",
            "MT",
            "MS",
            "MG",
            "PA",
            "PB",
            "PR",
            "PE",
            "PI",
            "RJ",
            "RN",
            "RS",
            "RO",
            "RR",
            "SC",
            "SP",
            "TO"});
            this.cbbAltUfCliente.Location = new System.Drawing.Point(270, 183);
            this.cbbAltUfCliente.Name = "cbbAltUfCliente";
            this.cbbAltUfCliente.Size = new System.Drawing.Size(148, 29);
            this.cbbAltUfCliente.TabIndex = 29;
            this.cbbAltUfCliente.UseSelectable = true;
            // 
            // metroLabel9
            // 
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.Location = new System.Drawing.Point(213, 193);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(25, 19);
            this.metroLabel9.TabIndex = 28;
            this.metroLabel9.Text = "UF";
            // 
            // metroLabel10
            // 
            this.metroLabel10.AutoSize = true;
            this.metroLabel10.Location = new System.Drawing.Point(192, 101);
            this.metroLabel10.Name = "metroLabel10";
            this.metroLabel10.Size = new System.Drawing.Size(54, 19);
            this.metroLabel10.TabIndex = 27;
            this.metroLabel10.Text = "Cidade:";
            // 
            // txtAltCidadeCliente
            // 
            this.txtAltCidadeCliente.Lines = new string[0];
            this.txtAltCidadeCliente.Location = new System.Drawing.Point(270, 97);
            this.txtAltCidadeCliente.MaxLength = 32767;
            this.txtAltCidadeCliente.Name = "txtAltCidadeCliente";
            this.txtAltCidadeCliente.PasswordChar = '\0';
            this.txtAltCidadeCliente.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtAltCidadeCliente.SelectedText = "";
            this.txtAltCidadeCliente.Size = new System.Drawing.Size(148, 23);
            this.txtAltCidadeCliente.TabIndex = 26;
            this.txtAltCidadeCliente.UseSelectable = true;
            // 
            // metroLabel11
            // 
            this.metroLabel11.AutoSize = true;
            this.metroLabel11.Location = new System.Drawing.Point(189, 130);
            this.metroLabel11.Name = "metroLabel11";
            this.metroLabel11.Size = new System.Drawing.Size(57, 19);
            this.metroLabel11.TabIndex = 25;
            this.metroLabel11.Text = "Telefone";
            // 
            // txtAltTelefoneCliente
            // 
            this.txtAltTelefoneCliente.Lines = new string[0];
            this.txtAltTelefoneCliente.Location = new System.Drawing.Point(270, 126);
            this.txtAltTelefoneCliente.MaxLength = 32767;
            this.txtAltTelefoneCliente.Name = "txtAltTelefoneCliente";
            this.txtAltTelefoneCliente.PasswordChar = '\0';
            this.txtAltTelefoneCliente.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtAltTelefoneCliente.SelectedText = "";
            this.txtAltTelefoneCliente.Size = new System.Drawing.Size(148, 23);
            this.txtAltTelefoneCliente.TabIndex = 24;
            this.txtAltTelefoneCliente.UseSelectable = true;
            this.txtAltTelefoneCliente.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAdiTelefoneCliente_KeyPress);
            // 
            // metroLabel12
            // 
            this.metroLabel12.AutoSize = true;
            this.metroLabel12.Location = new System.Drawing.Point(189, 72);
            this.metroLabel12.Name = "metroLabel12";
            this.metroLabel12.Size = new System.Drawing.Size(75, 19);
            this.metroLabel12.TabIndex = 23;
            this.metroLabel12.Text = "Referências";
            // 
            // txtAltReferenciasCliente
            // 
            this.txtAltReferenciasCliente.Lines = new string[0];
            this.txtAltReferenciasCliente.Location = new System.Drawing.Point(270, 68);
            this.txtAltReferenciasCliente.MaxLength = 32767;
            this.txtAltReferenciasCliente.Name = "txtAltReferenciasCliente";
            this.txtAltReferenciasCliente.PasswordChar = '\0';
            this.txtAltReferenciasCliente.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtAltReferenciasCliente.SelectedText = "";
            this.txtAltReferenciasCliente.Size = new System.Drawing.Size(148, 23);
            this.txtAltReferenciasCliente.TabIndex = 22;
            this.txtAltReferenciasCliente.UseSelectable = true;
            // 
            // metroLabel13
            // 
            this.metroLabel13.AutoSize = true;
            this.metroLabel13.Location = new System.Drawing.Point(192, 158);
            this.metroLabel13.Name = "metroLabel13";
            this.metroLabel13.Size = new System.Drawing.Size(64, 19);
            this.metroLabel13.TabIndex = 21;
            this.metroLabel13.Text = "Endereço";
            // 
            // txtAltEnderecoCliente
            // 
            this.txtAltEnderecoCliente.Lines = new string[0];
            this.txtAltEnderecoCliente.Location = new System.Drawing.Point(270, 154);
            this.txtAltEnderecoCliente.MaxLength = 32767;
            this.txtAltEnderecoCliente.Name = "txtAltEnderecoCliente";
            this.txtAltEnderecoCliente.PasswordChar = '\0';
            this.txtAltEnderecoCliente.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtAltEnderecoCliente.SelectedText = "";
            this.txtAltEnderecoCliente.Size = new System.Drawing.Size(148, 23);
            this.txtAltEnderecoCliente.TabIndex = 20;
            this.txtAltEnderecoCliente.UseSelectable = true;
            // 
            // metroLabel14
            // 
            this.metroLabel14.AutoSize = true;
            this.metroLabel14.Location = new System.Drawing.Point(192, 43);
            this.metroLabel14.Name = "metroLabel14";
            this.metroLabel14.Size = new System.Drawing.Size(46, 19);
            this.metroLabel14.TabIndex = 19;
            this.metroLabel14.Text = "Nome";
            // 
            // txtAltNomeCliente
            // 
            this.txtAltNomeCliente.Lines = new string[0];
            this.txtAltNomeCliente.Location = new System.Drawing.Point(270, 39);
            this.txtAltNomeCliente.MaxLength = 32767;
            this.txtAltNomeCliente.Name = "txtAltNomeCliente";
            this.txtAltNomeCliente.PasswordChar = '\0';
            this.txtAltNomeCliente.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtAltNomeCliente.SelectedText = "";
            this.txtAltNomeCliente.Size = new System.Drawing.Size(271, 23);
            this.txtAltNomeCliente.TabIndex = 18;
            this.txtAltNomeCliente.UseSelectable = true;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(57, 57);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(126, 128);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 30;
            this.pictureBox4.TabStop = false;
            // 
            // mtpRemover
            // 
            this.mtpRemover.Controls.Add(this.metroLabel8);
            this.mtpRemover.Controls.Add(this.txtExcNomeCliente);
            this.mtpRemover.Controls.Add(this.bntExluirCliente);
            this.mtpRemover.Controls.Add(this.pictureBox5);
            this.mtpRemover.Controls.Add(this.metroLabel20);
            this.mtpRemover.Controls.Add(this.txtExcIdCliente);
            this.mtpRemover.HorizontalScrollbarBarColor = true;
            this.mtpRemover.HorizontalScrollbarHighlightOnWheel = false;
            this.mtpRemover.HorizontalScrollbarSize = 10;
            this.mtpRemover.Location = new System.Drawing.Point(4, 4);
            this.mtpRemover.Name = "mtpRemover";
            this.mtpRemover.Size = new System.Drawing.Size(598, 214);
            this.mtpRemover.TabIndex = 2;
            this.mtpRemover.Text = "Remover";
            this.mtpRemover.VerticalScrollbarBarColor = true;
            this.mtpRemover.VerticalScrollbarHighlightOnWheel = false;
            this.mtpRemover.VerticalScrollbarSize = 10;
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.Location = new System.Drawing.Point(211, 79);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(46, 19);
            this.metroLabel8.TabIndex = 34;
            this.metroLabel8.Text = "Nome";
            // 
            // txtExcNomeCliente
            // 
            this.txtExcNomeCliente.Enabled = false;
            this.txtExcNomeCliente.Lines = new string[0];
            this.txtExcNomeCliente.Location = new System.Drawing.Point(263, 75);
            this.txtExcNomeCliente.MaxLength = 32767;
            this.txtExcNomeCliente.Name = "txtExcNomeCliente";
            this.txtExcNomeCliente.PasswordChar = '\0';
            this.txtExcNomeCliente.ReadOnly = true;
            this.txtExcNomeCliente.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtExcNomeCliente.SelectedText = "";
            this.txtExcNomeCliente.Size = new System.Drawing.Size(271, 23);
            this.txtExcNomeCliente.TabIndex = 33;
            this.txtExcNomeCliente.UseSelectable = true;
            // 
            // bntExluirCliente
            // 
            this.bntExluirCliente.ActiveControl = null;
            this.bntExluirCliente.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bntExluirCliente.Location = new System.Drawing.Point(263, 114);
            this.bntExluirCliente.Name = "bntExluirCliente";
            this.bntExluirCliente.Size = new System.Drawing.Size(271, 42);
            this.bntExluirCliente.Style = MetroFramework.MetroColorStyle.Red;
            this.bntExluirCliente.TabIndex = 32;
            this.bntExluirCliente.Text = "Excluir";
            this.bntExluirCliente.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bntExluirCliente.Theme = MetroFramework.MetroThemeStyle.Light;
            this.bntExluirCliente.UseSelectable = true;
            this.bntExluirCliente.Click += new System.EventHandler(this.bntExluirCliente_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(57, 57);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(126, 128);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 30;
            this.pictureBox5.TabStop = false;
            // 
            // metroLabel20
            // 
            this.metroLabel20.AutoSize = true;
            this.metroLabel20.Location = new System.Drawing.Point(211, 50);
            this.metroLabel20.Name = "metroLabel20";
            this.metroLabel20.Size = new System.Drawing.Size(53, 19);
            this.metroLabel20.TabIndex = 19;
            this.metroLabel20.Text = "Código";
            // 
            // txtExcIdCliente
            // 
            this.txtExcIdCliente.Enabled = false;
            this.txtExcIdCliente.Lines = new string[0];
            this.txtExcIdCliente.Location = new System.Drawing.Point(263, 46);
            this.txtExcIdCliente.MaxLength = 32767;
            this.txtExcIdCliente.Name = "txtExcIdCliente";
            this.txtExcIdCliente.PasswordChar = '\0';
            this.txtExcIdCliente.ReadOnly = true;
            this.txtExcIdCliente.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtExcIdCliente.SelectedText = "";
            this.txtExcIdCliente.Size = new System.Drawing.Size(93, 23);
            this.txtExcIdCliente.TabIndex = 18;
            this.txtExcIdCliente.UseSelectable = true;
            // 
            // dgvClientes
            // 
            this.dgvClientes.AllowUserToOrderColumns = true;
            this.dgvClientes.AllowUserToResizeRows = false;
            this.dgvClientes.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvClientes.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvClientes.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvClientes.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvClientes.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvClientes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvClientes.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvClientes.EnableHeadersVisualStyles = false;
            this.dgvClientes.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvClientes.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvClientes.Location = new System.Drawing.Point(0, 22);
            this.dgvClientes.Name = "dgvClientes";
            this.dgvClientes.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvClientes.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvClientes.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvClientes.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvClientes.Size = new System.Drawing.Size(999, 184);
            this.dgvClientes.Style = MetroFramework.MetroColorStyle.Red;
            this.dgvClientes.TabIndex = 2;
            this.dgvClientes.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvClientes_CellClick);
            // 
            // tpPedidos
            // 
            this.tpPedidos.Controls.Add(this.groupBox3);
            this.tpPedidos.HorizontalScrollbarBarColor = true;
            this.tpPedidos.HorizontalScrollbarHighlightOnWheel = false;
            this.tpPedidos.HorizontalScrollbarSize = 10;
            this.tpPedidos.Location = new System.Drawing.Point(4, 38);
            this.tpPedidos.Name = "tpPedidos";
            this.tpPedidos.Size = new System.Drawing.Size(1014, 553);
            this.tpPedidos.TabIndex = 1;
            this.tpPedidos.Text = "Pedidos";
            this.tpPedidos.VerticalScrollbarBarColor = true;
            this.tpPedidos.VerticalScrollbarHighlightOnWheel = false;
            this.tpPedidos.VerticalScrollbarSize = 10;
            this.tpPedidos.Click += new System.EventHandler(this.tpPedidos_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.Transparent;
            this.groupBox3.Controls.Add(this.groupBox6);
            this.groupBox3.Controls.Add(this.gbxTabela);
            this.groupBox3.Controls.Add(this.groupBox4);
            this.groupBox3.Controls.Add(this.groupBox5);
            this.groupBox3.Location = new System.Drawing.Point(78, 12);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(836, 538);
            this.groupBox3.TabIndex = 36;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Efetuar Pedidos";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.bntCancelarPedidos);
            this.groupBox6.Controls.Add(this.bntAdicionarPedido);
            this.groupBox6.Controls.Add(this.pictureBox6);
            this.groupBox6.Controls.Add(this.metroLabel16);
            this.groupBox6.Controls.Add(this.metroLabel18);
            this.groupBox6.Controls.Add(this.metroLabel22);
            this.groupBox6.Controls.Add(this.txtCaixa);
            this.groupBox6.Controls.Add(this.txtCustoTotal);
            this.groupBox6.Location = new System.Drawing.Point(436, 181);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(394, 334);
            this.groupBox6.TabIndex = 54;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Finalização de Pedido";
            // 
            // bntCancelarPedidos
            // 
            this.bntCancelarPedidos.ActiveControl = null;
            this.bntCancelarPedidos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bntCancelarPedidos.Location = new System.Drawing.Point(65, 222);
            this.bntCancelarPedidos.Name = "bntCancelarPedidos";
            this.bntCancelarPedidos.Size = new System.Drawing.Size(270, 34);
            this.bntCancelarPedidos.Style = MetroFramework.MetroColorStyle.Silver;
            this.bntCancelarPedidos.TabIndex = 67;
            this.bntCancelarPedidos.Text = "Cancelar e Limpar Pedidos";
            this.bntCancelarPedidos.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bntCancelarPedidos.Theme = MetroFramework.MetroThemeStyle.Light;
            this.bntCancelarPedidos.UseSelectable = true;
            this.bntCancelarPedidos.Click += new System.EventHandler(this.bntCancelarPedidos_Click);
            // 
            // bntAdicionarPedido
            // 
            this.bntAdicionarPedido.ActiveControl = null;
            this.bntAdicionarPedido.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bntAdicionarPedido.Location = new System.Drawing.Point(65, 262);
            this.bntAdicionarPedido.Name = "bntAdicionarPedido";
            this.bntAdicionarPedido.Size = new System.Drawing.Size(270, 60);
            this.bntAdicionarPedido.Style = MetroFramework.MetroColorStyle.Red;
            this.bntAdicionarPedido.TabIndex = 66;
            this.bntAdicionarPedido.Text = "Efetuar Pedidos";
            this.bntAdicionarPedido.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bntAdicionarPedido.Theme = MetroFramework.MetroThemeStyle.Light;
            this.bntAdicionarPedido.UseSelectable = true;
            this.bntAdicionarPedido.Click += new System.EventHandler(this.bntAdicionarPedido_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::PizzariaMania.Properties.Resources.electronic_billing_machine_icon;
            this.pictureBox6.Location = new System.Drawing.Point(138, 36);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(119, 100);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 49;
            this.pictureBox6.TabStop = false;
            // 
            // metroLabel16
            // 
            this.metroLabel16.AutoSize = true;
            this.metroLabel16.Location = new System.Drawing.Point(59, 153);
            this.metroLabel16.Name = "metroLabel16";
            this.metroLabel16.Size = new System.Drawing.Size(73, 19);
            this.metroLabel16.TabIndex = 33;
            this.metroLabel16.Text = "Custo Total";
            this.metroLabel16.Click += new System.EventHandler(this.metroLabel16_Click);
            // 
            // metroLabel18
            // 
            this.metroLabel18.AutoSize = true;
            this.metroLabel18.Location = new System.Drawing.Point(65, 182);
            this.metroLabel18.Name = "metroLabel18";
            this.metroLabel18.Size = new System.Drawing.Size(41, 19);
            this.metroLabel18.TabIndex = 29;
            this.metroLabel18.Text = "Caixa";
            this.metroLabel18.Click += new System.EventHandler(this.metroLabel18_Click);
            // 
            // metroLabel22
            // 
            this.metroLabel22.AutoSize = true;
            this.metroLabel22.Location = new System.Drawing.Point(12, 119);
            this.metroLabel22.Name = "metroLabel22";
            this.metroLabel22.Size = new System.Drawing.Size(0, 0);
            this.metroLabel22.TabIndex = 53;
            // 
            // txtCaixa
            // 
            this.txtCaixa.Lines = new string[0];
            this.txtCaixa.Location = new System.Drawing.Point(138, 182);
            this.txtCaixa.MaxLength = 32767;
            this.txtCaixa.Name = "txtCaixa";
            this.txtCaixa.PasswordChar = '\0';
            this.txtCaixa.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtCaixa.SelectedText = "";
            this.txtCaixa.Size = new System.Drawing.Size(197, 23);
            this.txtCaixa.TabIndex = 28;
            this.txtCaixa.UseSelectable = true;
            this.txtCaixa.Click += new System.EventHandler(this.metroTextBox4_Click);
            this.txtCaixa.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAdiTelefoneCliente_KeyPress);
            // 
            // txtCustoTotal
            // 
            this.txtCustoTotal.Enabled = false;
            this.txtCustoTotal.Lines = new string[0];
            this.txtCustoTotal.Location = new System.Drawing.Point(138, 153);
            this.txtCustoTotal.MaxLength = 32767;
            this.txtCustoTotal.Name = "txtCustoTotal";
            this.txtCustoTotal.PasswordChar = '\0';
            this.txtCustoTotal.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtCustoTotal.SelectedText = "";
            this.txtCustoTotal.Size = new System.Drawing.Size(197, 23);
            this.txtCustoTotal.TabIndex = 32;
            this.txtCustoTotal.UseSelectable = true;
            this.txtCustoTotal.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAdiTelefoneCliente_KeyPress);
            // 
            // gbxTabela
            // 
            this.gbxTabela.Controls.Add(this.bntAtualizaPizza);
            this.gbxTabela.Controls.Add(this.bntEditar);
            this.gbxTabela.Controls.Add(this.metroLabel25);
            this.gbxTabela.Controls.Add(this.dgvPizzas);
            this.gbxTabela.Location = new System.Drawing.Point(291, 19);
            this.gbxTabela.Name = "gbxTabela";
            this.gbxTabela.Size = new System.Drawing.Size(539, 156);
            this.gbxTabela.TabIndex = 51;
            this.gbxTabela.TabStop = false;
            this.gbxTabela.Text = "Tabela de Preço";
            // 
            // bntAtualizaPizza
            // 
            this.bntAtualizaPizza.Location = new System.Drawing.Point(183, 131);
            this.bntAtualizaPizza.Name = "bntAtualizaPizza";
            this.bntAtualizaPizza.Size = new System.Drawing.Size(71, 20);
            this.bntAtualizaPizza.TabIndex = 73;
            this.bntAtualizaPizza.Text = "Atualizar";
            this.bntAtualizaPizza.UseSelectable = true;
            this.bntAtualizaPizza.Click += new System.EventHandler(this.bntAtualizaPizza_Click);
            // 
            // bntEditar
            // 
            this.bntEditar.Location = new System.Drawing.Point(106, 131);
            this.bntEditar.Name = "bntEditar";
            this.bntEditar.Size = new System.Drawing.Size(71, 20);
            this.bntEditar.TabIndex = 71;
            this.bntEditar.Text = "Editar";
            this.bntEditar.UseSelectable = true;
            this.bntEditar.Click += new System.EventHandler(this.bntEditar_Click);
            // 
            // metroLabel25
            // 
            this.metroLabel25.AutoSize = true;
            this.metroLabel25.Location = new System.Drawing.Point(15, 131);
            this.metroLabel25.Name = "metroLabel25";
            this.metroLabel25.Size = new System.Drawing.Size(84, 19);
            this.metroLabel25.TabIndex = 68;
            this.metroLabel25.Text = "Editar Tabela";
            // 
            // dgvPizzas
            // 
            this.dgvPizzas.AllowUserToOrderColumns = true;
            this.dgvPizzas.AllowUserToResizeRows = false;
            this.dgvPizzas.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvPizzas.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvPizzas.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvPizzas.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(85)))), ((int)(((byte)(85)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPizzas.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvPizzas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvPizzas.DefaultCellStyle = dataGridViewCellStyle5;
            this.dgvPizzas.EnableHeadersVisualStyles = false;
            this.dgvPizzas.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvPizzas.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvPizzas.Location = new System.Drawing.Point(6, 16);
            this.dgvPizzas.Name = "dgvPizzas";
            this.dgvPizzas.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(85)))), ((int)(((byte)(85)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPizzas.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dgvPizzas.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvPizzas.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPizzas.Size = new System.Drawing.Size(508, 101);
            this.dgvPizzas.Style = MetroFramework.MetroColorStyle.Silver;
            this.dgvPizzas.TabIndex = 67;
            this.dgvPizzas.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPizzas_CellClick);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.lblTesteListBox);
            this.groupBox4.Controls.Add(this.txtQuantidade);
            this.groupBox4.Controls.Add(this.groupBox7);
            this.groupBox4.Controls.Add(this.bntRemoverItens);
            this.groupBox4.Controls.Add(this.lbxItens);
            this.groupBox4.Controls.Add(this.bntLimparItens);
            this.groupBox4.Controls.Add(this.bntIntesAdicionar);
            this.groupBox4.Controls.Add(this.txtInfoPedido);
            this.groupBox4.Controls.Add(this.txtSaborPedido);
            this.groupBox4.Controls.Add(this.metroLabel24);
            this.groupBox4.Controls.Add(this.metroLabel23);
            this.groupBox4.Controls.Add(this.metroLabel19);
            this.groupBox4.Location = new System.Drawing.Point(14, 181);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(416, 334);
            this.groupBox4.TabIndex = 50;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Itens";
            // 
            // lblTesteListBox
            // 
            this.lblTesteListBox.AutoSize = true;
            this.lblTesteListBox.Location = new System.Drawing.Point(30, 315);
            this.lblTesteListBox.Name = "lblTesteListBox";
            this.lblTesteListBox.Size = new System.Drawing.Size(35, 13);
            this.lblTesteListBox.TabIndex = 72;
            this.lblTesteListBox.Text = "label1";
            this.lblTesteListBox.Visible = false;
            // 
            // txtQuantidade
            // 
            this.txtQuantidade.Lines = new string[0];
            this.txtQuantidade.Location = new System.Drawing.Point(118, 119);
            this.txtQuantidade.MaxLength = 32767;
            this.txtQuantidade.Name = "txtQuantidade";
            this.txtQuantidade.PasswordChar = '\0';
            this.txtQuantidade.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtQuantidade.SelectedText = "";
            this.txtQuantidade.Size = new System.Drawing.Size(127, 23);
            this.txtQuantidade.TabIndex = 71;
            this.txtQuantidade.UseSelectable = true;
            this.txtQuantidade.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAdiTelefoneCliente_KeyPress);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.rbtGrandeP);
            this.groupBox7.Controls.Add(this.rbtMediaP);
            this.groupBox7.Controls.Add(this.rbtPequenaP);
            this.groupBox7.Location = new System.Drawing.Point(264, 19);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(135, 118);
            this.groupBox7.TabIndex = 70;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Tipo de Preço";
            // 
            // rbtGrandeP
            // 
            this.rbtGrandeP.AutoSize = true;
            this.rbtGrandeP.Location = new System.Drawing.Point(6, 76);
            this.rbtGrandeP.Name = "rbtGrandeP";
            this.rbtGrandeP.Size = new System.Drawing.Size(63, 17);
            this.rbtGrandeP.TabIndex = 62;
            this.rbtGrandeP.TabStop = true;
            this.rbtGrandeP.Text = "Grande:";
            this.rbtGrandeP.UseVisualStyleBackColor = true;
            // 
            // rbtMediaP
            // 
            this.rbtMediaP.AutoSize = true;
            this.rbtMediaP.Location = new System.Drawing.Point(6, 50);
            this.rbtMediaP.Name = "rbtMediaP";
            this.rbtMediaP.Size = new System.Drawing.Size(57, 17);
            this.rbtMediaP.TabIndex = 61;
            this.rbtMediaP.TabStop = true;
            this.rbtMediaP.Text = "Média:";
            this.rbtMediaP.UseVisualStyleBackColor = true;
            // 
            // rbtPequenaP
            // 
            this.rbtPequenaP.AutoSize = true;
            this.rbtPequenaP.Location = new System.Drawing.Point(6, 27);
            this.rbtPequenaP.Name = "rbtPequenaP";
            this.rbtPequenaP.Size = new System.Drawing.Size(74, 17);
            this.rbtPequenaP.TabIndex = 60;
            this.rbtPequenaP.TabStop = true;
            this.rbtPequenaP.Text = "Pequena: ";
            this.rbtPequenaP.UseVisualStyleBackColor = true;
            // 
            // bntRemoverItens
            // 
            this.bntRemoverItens.Location = new System.Drawing.Point(17, 290);
            this.bntRemoverItens.Name = "bntRemoverItens";
            this.bntRemoverItens.Size = new System.Drawing.Size(184, 23);
            this.bntRemoverItens.TabIndex = 67;
            this.bntRemoverItens.Text = "Remover Itens";
            this.bntRemoverItens.UseSelectable = true;
            this.bntRemoverItens.Click += new System.EventHandler(this.bntRemoverItens_Click);
            // 
            // lbxItens
            // 
            this.lbxItens.FormattingEnabled = true;
            this.lbxItens.Location = new System.Drawing.Point(17, 174);
            this.lbxItens.Name = "lbxItens";
            this.lbxItens.Size = new System.Drawing.Size(393, 69);
            this.lbxItens.TabIndex = 69;
            this.lbxItens.SelectedIndexChanged += new System.EventHandler(this.lbxItens_SelectedIndexChanged);
            // 
            // bntLimparItens
            // 
            this.bntLimparItens.Location = new System.Drawing.Point(207, 289);
            this.bntLimparItens.Name = "bntLimparItens";
            this.bntLimparItens.Size = new System.Drawing.Size(203, 24);
            this.bntLimparItens.TabIndex = 65;
            this.bntLimparItens.Text = "Limpar todos os Itens";
            this.bntLimparItens.UseSelectable = true;
            this.bntLimparItens.Click += new System.EventHandler(this.bntLimparItens_Click);
            // 
            // bntIntesAdicionar
            // 
            this.bntIntesAdicionar.ActiveControl = null;
            this.bntIntesAdicionar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bntIntesAdicionar.Location = new System.Drawing.Point(17, 249);
            this.bntIntesAdicionar.Name = "bntIntesAdicionar";
            this.bntIntesAdicionar.Size = new System.Drawing.Size(393, 34);
            this.bntIntesAdicionar.Style = MetroFramework.MetroColorStyle.Silver;
            this.bntIntesAdicionar.TabIndex = 64;
            this.bntIntesAdicionar.Text = "Adicionar Itens";
            this.bntIntesAdicionar.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bntIntesAdicionar.Theme = MetroFramework.MetroThemeStyle.Light;
            this.bntIntesAdicionar.UseSelectable = true;
            this.bntIntesAdicionar.Click += new System.EventHandler(this.bntIntesAdicionar_Click);
            // 
            // txtInfoPedido
            // 
            this.txtInfoPedido.Enabled = false;
            this.txtInfoPedido.Lines = new string[0];
            this.txtInfoPedido.Location = new System.Drawing.Point(30, 89);
            this.txtInfoPedido.MaxLength = 32767;
            this.txtInfoPedido.Name = "txtInfoPedido";
            this.txtInfoPedido.PasswordChar = '\0';
            this.txtInfoPedido.ReadOnly = true;
            this.txtInfoPedido.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtInfoPedido.SelectedText = "";
            this.txtInfoPedido.Size = new System.Drawing.Size(215, 23);
            this.txtInfoPedido.TabIndex = 63;
            this.txtInfoPedido.UseSelectable = true;
            // 
            // txtSaborPedido
            // 
            this.txtSaborPedido.Enabled = false;
            this.txtSaborPedido.Lines = new string[0];
            this.txtSaborPedido.Location = new System.Drawing.Point(30, 40);
            this.txtSaborPedido.MaxLength = 32767;
            this.txtSaborPedido.Name = "txtSaborPedido";
            this.txtSaborPedido.PasswordChar = '\0';
            this.txtSaborPedido.ReadOnly = true;
            this.txtSaborPedido.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtSaborPedido.SelectedText = "";
            this.txtSaborPedido.Size = new System.Drawing.Size(215, 23);
            this.txtSaborPedido.TabIndex = 62;
            this.txtSaborPedido.UseSelectable = true;
            // 
            // metroLabel24
            // 
            this.metroLabel24.AutoSize = true;
            this.metroLabel24.Location = new System.Drawing.Point(30, 19);
            this.metroLabel24.Name = "metroLabel24";
            this.metroLabel24.Size = new System.Drawing.Size(44, 19);
            this.metroLabel24.TabIndex = 61;
            this.metroLabel24.Text = "Sabor";
            // 
            // metroLabel23
            // 
            this.metroLabel23.AutoSize = true;
            this.metroLabel23.Location = new System.Drawing.Point(30, 67);
            this.metroLabel23.Name = "metroLabel23";
            this.metroLabel23.Size = new System.Drawing.Size(81, 19);
            this.metroLabel23.TabIndex = 55;
            this.metroLabel23.Text = "Informações";
            // 
            // metroLabel19
            // 
            this.metroLabel19.AutoSize = true;
            this.metroLabel19.Location = new System.Drawing.Point(33, 118);
            this.metroLabel19.Name = "metroLabel19";
            this.metroLabel19.Size = new System.Drawing.Size(78, 19);
            this.metroLabel19.TabIndex = 51;
            this.metroLabel19.Text = "Quantidade";
            this.metroLabel19.Click += new System.EventHandler(this.metroLabel19_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.lblIDClienteTs);
            this.groupBox5.Controls.Add(this.txtNomePedido);
            this.groupBox5.Controls.Add(this.bntProcuraCliente);
            this.groupBox5.Controls.Add(this.txtTelefonePedido);
            this.groupBox5.Controls.Add(this.metroLabel17);
            this.groupBox5.Controls.Add(this.txtDataPedido);
            this.groupBox5.Controls.Add(this.metroLabel15);
            this.groupBox5.Controls.Add(this.metroLabel21);
            this.groupBox5.Location = new System.Drawing.Point(14, 19);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(271, 156);
            this.groupBox5.TabIndex = 47;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Consumidor";
            // 
            // lblIDClienteTs
            // 
            this.lblIDClienteTs.AutoSize = true;
            this.lblIDClienteTs.Location = new System.Drawing.Point(14, 16);
            this.lblIDClienteTs.Name = "lblIDClienteTs";
            this.lblIDClienteTs.Size = new System.Drawing.Size(62, 13);
            this.lblIDClienteTs.TabIndex = 42;
            this.lblIDClienteTs.Text = "IDClienteTs";
            this.lblIDClienteTs.Visible = false;
            // 
            // txtNomePedido
            // 
            this.txtNomePedido.Enabled = false;
            this.txtNomePedido.Lines = new string[0];
            this.txtNomePedido.Location = new System.Drawing.Point(77, 34);
            this.txtNomePedido.MaxLength = 32767;
            this.txtNomePedido.Name = "txtNomePedido";
            this.txtNomePedido.PasswordChar = '\0';
            this.txtNomePedido.ReadOnly = true;
            this.txtNomePedido.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtNomePedido.SelectedText = "";
            this.txtNomePedido.Size = new System.Drawing.Size(168, 23);
            this.txtNomePedido.TabIndex = 41;
            this.txtNomePedido.UseSelectable = true;
            this.txtNomePedido.Click += new System.EventHandler(this.txtNomePedido_Click);
            // 
            // bntProcuraCliente
            // 
            this.bntProcuraCliente.Location = new System.Drawing.Point(77, 121);
            this.bntProcuraCliente.Name = "bntProcuraCliente";
            this.bntProcuraCliente.Size = new System.Drawing.Size(168, 25);
            this.bntProcuraCliente.TabIndex = 40;
            this.bntProcuraCliente.Text = "Procurar";
            this.bntProcuraCliente.UseSelectable = true;
            this.bntProcuraCliente.Click += new System.EventHandler(this.bntProcuraCliente_Click);
            // 
            // txtTelefonePedido
            // 
            this.txtTelefonePedido.Enabled = false;
            this.txtTelefonePedido.Lines = new string[0];
            this.txtTelefonePedido.Location = new System.Drawing.Point(77, 63);
            this.txtTelefonePedido.MaxLength = 32767;
            this.txtTelefonePedido.Name = "txtTelefonePedido";
            this.txtTelefonePedido.PasswordChar = '\0';
            this.txtTelefonePedido.ReadOnly = true;
            this.txtTelefonePedido.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtTelefonePedido.SelectedText = "";
            this.txtTelefonePedido.Size = new System.Drawing.Size(168, 23);
            this.txtTelefonePedido.TabIndex = 30;
            this.txtTelefonePedido.UseSelectable = true;
            // 
            // metroLabel17
            // 
            this.metroLabel17.AutoSize = true;
            this.metroLabel17.Location = new System.Drawing.Point(14, 67);
            this.metroLabel17.Name = "metroLabel17";
            this.metroLabel17.Size = new System.Drawing.Size(57, 19);
            this.metroLabel17.TabIndex = 31;
            this.metroLabel17.Text = "Telefone";
            // 
            // txtDataPedido
            // 
            this.txtDataPedido.Enabled = false;
            this.txtDataPedido.Lines = new string[0];
            this.txtDataPedido.Location = new System.Drawing.Point(77, 92);
            this.txtDataPedido.MaxLength = 32767;
            this.txtDataPedido.Name = "txtDataPedido";
            this.txtDataPedido.PasswordChar = '\0';
            this.txtDataPedido.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtDataPedido.SelectedText = "";
            this.txtDataPedido.Size = new System.Drawing.Size(168, 23);
            this.txtDataPedido.TabIndex = 34;
            this.txtDataPedido.UseSelectable = true;
            // 
            // metroLabel15
            // 
            this.metroLabel15.AutoSize = true;
            this.metroLabel15.Location = new System.Drawing.Point(35, 96);
            this.metroLabel15.Name = "metroLabel15";
            this.metroLabel15.Size = new System.Drawing.Size(36, 19);
            this.metroLabel15.TabIndex = 35;
            this.metroLabel15.Text = "Data";
            // 
            // metroLabel21
            // 
            this.metroLabel21.AutoSize = true;
            this.metroLabel21.Location = new System.Drawing.Point(17, 36);
            this.metroLabel21.Name = "metroLabel21";
            this.metroLabel21.Size = new System.Drawing.Size(54, 19);
            this.metroLabel21.TabIndex = 39;
            this.metroLabel21.Text = "Clientes";
            // 
            // tbRelatorios
            // 
            this.tbRelatorios.Controls.Add(this.tbMenuRelatorio);
            this.tbRelatorios.HorizontalScrollbarBarColor = true;
            this.tbRelatorios.HorizontalScrollbarHighlightOnWheel = false;
            this.tbRelatorios.HorizontalScrollbarSize = 10;
            this.tbRelatorios.Location = new System.Drawing.Point(4, 38);
            this.tbRelatorios.Name = "tbRelatorios";
            this.tbRelatorios.Size = new System.Drawing.Size(1014, 553);
            this.tbRelatorios.TabIndex = 3;
            this.tbRelatorios.Text = "Relatórios";
            this.tbRelatorios.VerticalScrollbarBarColor = true;
            this.tbRelatorios.VerticalScrollbarHighlightOnWheel = false;
            this.tbRelatorios.VerticalScrollbarSize = 10;
            this.tbRelatorios.Click += new System.EventHandler(this.tbRelatorios_Click);
            // 
            // tbMenuRelatorio
            // 
            this.tbMenuRelatorio.BackColor = System.Drawing.Color.Transparent;
            this.tbMenuRelatorio.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tbMenuRelatorio.CanReorderTabs = true;
            this.tbMenuRelatorio.ColorScheme.TabBorder = System.Drawing.Color.Gray;
            this.tbMenuRelatorio.ColorScheme.TabItemBackgroundColorBlend.AddRange(new DevComponents.DotNetBar.BackgroundColorBlend[] {
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.Empty, 0F),
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.Empty, 0.45F),
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.Empty, 0.45F),
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.Empty, 1F)});
            this.tbMenuRelatorio.ColorScheme.TabItemHotBackgroundColorBlend.AddRange(new DevComponents.DotNetBar.BackgroundColorBlend[] {
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.Empty, 0F),
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.Empty, 0.45F),
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.Empty, 0.45F),
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.Empty, 1F)});
            this.tbMenuRelatorio.ColorScheme.TabItemHotText = System.Drawing.Color.Black;
            this.tbMenuRelatorio.ColorScheme.TabItemSelectedBackgroundColorBlend.AddRange(new DevComponents.DotNetBar.BackgroundColorBlend[] {
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.Empty, 0F),
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.Empty, 0.45F),
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.Empty, 0.45F),
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.Empty, 1F)});
            this.tbMenuRelatorio.ColorScheme.TabItemSelectedText = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.tbMenuRelatorio.Controls.Add(this.tabControlPanel7);
            this.tbMenuRelatorio.Controls.Add(this.tabControlPanel5);
            this.tbMenuRelatorio.Controls.Add(this.tabControlPanel6);
            this.tbMenuRelatorio.ForeColor = System.Drawing.Color.Black;
            this.tbMenuRelatorio.Location = new System.Drawing.Point(24, 22);
            this.tbMenuRelatorio.Name = "tbMenuRelatorio";
            this.tbMenuRelatorio.SelectedTabFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.tbMenuRelatorio.SelectedTabIndex = 0;
            this.tbMenuRelatorio.Size = new System.Drawing.Size(970, 528);
            this.tbMenuRelatorio.Style = DevComponents.DotNetBar.eTabStripStyle.Office2003;
            this.tbMenuRelatorio.TabIndex = 22;
            this.tbMenuRelatorio.TabLayoutType = DevComponents.DotNetBar.eTabLayoutType.FixedWithNavigationBox;
            this.tbMenuRelatorio.Tabs.Add(this.tbPedidosRealizados);
            this.tbMenuRelatorio.Tabs.Add(this.tbTabelaPizza);
            this.tbMenuRelatorio.Tabs.Add(this.tbRegistro);
            this.tbMenuRelatorio.Text = "Relatórios";
            this.tbMenuRelatorio.ThemeAware = true;
            // 
            // tabControlPanel6
            // 
            this.tabControlPanel6.Controls.Add(this.groupBox15);
            this.tabControlPanel6.Controls.Add(this.groupBox16);
            this.tabControlPanel6.Controls.Add(this.pictureBox14);
            this.tabControlPanel6.Controls.Add(this.htmlLabel2);
            this.tabControlPanel6.DisabledBackColor = System.Drawing.Color.Empty;
            this.tabControlPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlPanel6.Location = new System.Drawing.Point(0, 26);
            this.tabControlPanel6.Name = "tabControlPanel6";
            this.tabControlPanel6.Padding = new System.Windows.Forms.Padding(1);
            this.tabControlPanel6.Size = new System.Drawing.Size(970, 502);
            this.tabControlPanel6.Style.BackColor1.Color = System.Drawing.SystemColors.Control;
            this.tabControlPanel6.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.tabControlPanel6.Style.BorderSide = ((DevComponents.DotNetBar.eBorderSide)(((DevComponents.DotNetBar.eBorderSide.Left | DevComponents.DotNetBar.eBorderSide.Right)
                        | DevComponents.DotNetBar.eBorderSide.Bottom)));
            this.tabControlPanel6.Style.GradientAngle = 90;
            this.tabControlPanel6.TabIndex = 3;
            this.tabControlPanel6.TabItem = this.tbTabelaPizza;
            this.tabControlPanel6.Text = "Informações gerais";
            this.tabControlPanel6.ThemeAware = true;
            // 
            // groupBox15
            // 
            this.groupBox15.BackColor = System.Drawing.Color.Transparent;
            this.groupBox15.Controls.Add(this.dgvPizzas2);
            this.groupBox15.Location = new System.Drawing.Point(54, 96);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(671, 306);
            this.groupBox15.TabIndex = 22;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "Exibição de Pedidos";
            // 
            // dgvPizzas2
            // 
            this.dgvPizzas2.AllowUserToOrderColumns = true;
            this.dgvPizzas2.AllowUserToResizeRows = false;
            this.dgvPizzas2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvPizzas2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvPizzas2.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvPizzas2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPizzas2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.dgvPizzas2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvPizzas2.DefaultCellStyle = dataGridViewCellStyle14;
            this.dgvPizzas2.EnableHeadersVisualStyles = false;
            this.dgvPizzas2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvPizzas2.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvPizzas2.Location = new System.Drawing.Point(6, 19);
            this.dgvPizzas2.Name = "dgvPizzas2";
            this.dgvPizzas2.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPizzas2.RowHeadersDefaultCellStyle = dataGridViewCellStyle15;
            this.dgvPizzas2.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvPizzas2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPizzas2.Size = new System.Drawing.Size(659, 281);
            this.dgvPizzas2.Style = MetroFramework.MetroColorStyle.Red;
            this.dgvPizzas2.TabIndex = 68;
            // 
            // groupBox16
            // 
            this.groupBox16.BackColor = System.Drawing.Color.Transparent;
            this.groupBox16.Controls.Add(this.metroLabel29);
            this.groupBox16.Controls.Add(this.bntPizzasEditar);
            this.groupBox16.Controls.Add(this.cbPizzaEditar);
            this.groupBox16.Location = new System.Drawing.Point(731, 96);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(185, 306);
            this.groupBox16.TabIndex = 21;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "Consultas";
            // 
            // metroLabel29
            // 
            this.metroLabel29.AutoSize = true;
            this.metroLabel29.Location = new System.Drawing.Point(14, 46);
            this.metroLabel29.Name = "metroLabel29";
            this.metroLabel29.Size = new System.Drawing.Size(165, 19);
            this.metroLabel29.TabIndex = 11;
            this.metroLabel29.Text = "Selecione o tipo de edição";
            // 
            // bntPizzasEditar
            // 
            this.bntPizzasEditar.ActiveControl = null;
            this.bntPizzasEditar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bntPizzasEditar.Location = new System.Drawing.Point(28, 160);
            this.bntPizzasEditar.Name = "bntPizzasEditar";
            this.bntPizzasEditar.Size = new System.Drawing.Size(133, 104);
            this.bntPizzasEditar.Style = MetroFramework.MetroColorStyle.Red;
            this.bntPizzasEditar.TabIndex = 7;
            this.bntPizzasEditar.Text = "Exibir Edição";
            this.bntPizzasEditar.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bntPizzasEditar.Theme = MetroFramework.MetroThemeStyle.Light;
            this.bntPizzasEditar.UseSelectable = true;
            this.bntPizzasEditar.Click += new System.EventHandler(this.bntPizzasEditar_Click);
            // 
            // cbPizzaEditar
            // 
            this.cbPizzaEditar.FormattingEnabled = true;
            this.cbPizzaEditar.ItemHeight = 23;
            this.cbPizzaEditar.Items.AddRange(new object[] {
            "Adicionar",
            "Altera",
            "Excluír"});
            this.cbPizzaEditar.Location = new System.Drawing.Point(28, 68);
            this.cbPizzaEditar.Name = "cbPizzaEditar";
            this.cbPizzaEditar.Size = new System.Drawing.Size(133, 29);
            this.cbPizzaEditar.TabIndex = 0;
            this.cbPizzaEditar.UseSelectable = true;
            this.cbPizzaEditar.SelectedIndexChanged += new System.EventHandler(this.metroComboBox1_SelectedIndexChanged);
            // 
            // pictureBox14
            // 
            this.pictureBox14.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox14.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox14.Image")));
            this.pictureBox14.Location = new System.Drawing.Point(247, 18);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(64, 64);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox14.TabIndex = 20;
            this.pictureBox14.TabStop = false;
            // 
            // htmlLabel2
            // 
            this.htmlLabel2.AutoScroll = true;
            this.htmlLabel2.AutoScrollMinSize = new System.Drawing.Size(267, 48);
            this.htmlLabel2.AutoSize = false;
            this.htmlLabel2.BackColor = System.Drawing.SystemColors.Window;
            this.htmlLabel2.Location = new System.Drawing.Point(317, 30);
            this.htmlLabel2.Name = "htmlLabel2";
            this.htmlLabel2.Size = new System.Drawing.Size(321, 52);
            this.htmlLabel2.TabIndex = 19;
            this.htmlLabel2.Text = "Tabela de Preços";
            // 
            // tbTabelaPizza
            // 
            this.tbTabelaPizza.AttachedControl = this.tabControlPanel6;
            this.tbTabelaPizza.Name = "tbTabelaPizza";
            this.tbTabelaPizza.Text = "Tabela de Pizza";
            // 
            // tabControlPanel5
            // 
            this.tabControlPanel5.Controls.Add(this.groupBox12);
            this.tabControlPanel5.Controls.Add(this.groupBox11);
            this.tabControlPanel5.Controls.Add(this.groupBox13);
            this.tabControlPanel5.Controls.Add(this.groupBox9);
            this.tabControlPanel5.Controls.Add(this.htmlLabel1);
            this.tabControlPanel5.Controls.Add(this.pictureBox9);
            this.tabControlPanel5.DisabledBackColor = System.Drawing.Color.Empty;
            this.tabControlPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlPanel5.Location = new System.Drawing.Point(0, 26);
            this.tabControlPanel5.Name = "tabControlPanel5";
            this.tabControlPanel5.Padding = new System.Windows.Forms.Padding(1);
            this.tabControlPanel5.Size = new System.Drawing.Size(970, 502);
            this.tabControlPanel5.Style.BackColor1.Color = System.Drawing.SystemColors.Control;
            this.tabControlPanel5.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.tabControlPanel5.Style.BorderSide = ((DevComponents.DotNetBar.eBorderSide)(((DevComponents.DotNetBar.eBorderSide.Left | DevComponents.DotNetBar.eBorderSide.Right)
                        | DevComponents.DotNetBar.eBorderSide.Bottom)));
            this.tabControlPanel5.Style.GradientAngle = 90;
            this.tabControlPanel5.TabIndex = 1;
            this.tabControlPanel5.TabItem = this.tbPedidosRealizados;
            this.tabControlPanel5.ThemeAware = true;
            // 
            // groupBox12
            // 
            this.groupBox12.BackColor = System.Drawing.Color.Transparent;
            this.groupBox12.Controls.Add(this.dgvPedidos);
            this.groupBox12.Location = new System.Drawing.Point(58, 84);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(671, 306);
            this.groupBox12.TabIndex = 18;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Exibição de Pedidos";
            // 
            // dgvPedidos
            // 
            this.dgvPedidos.AllowUserToOrderColumns = true;
            this.dgvPedidos.AllowUserToResizeRows = false;
            this.dgvPedidos.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvPedidos.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvPedidos.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvPedidos.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPedidos.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.dgvPedidos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvPedidos.DefaultCellStyle = dataGridViewCellStyle11;
            this.dgvPedidos.EnableHeadersVisualStyles = false;
            this.dgvPedidos.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvPedidos.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvPedidos.Location = new System.Drawing.Point(6, 16);
            this.dgvPedidos.Name = "dgvPedidos";
            this.dgvPedidos.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPedidos.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.dgvPedidos.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvPedidos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPedidos.Size = new System.Drawing.Size(659, 281);
            this.dgvPedidos.Style = MetroFramework.MetroColorStyle.Red;
            this.dgvPedidos.TabIndex = 4;
            // 
            // groupBox11
            // 
            this.groupBox11.BackColor = System.Drawing.Color.Transparent;
            this.groupBox11.Controls.Add(this.metroLabel28);
            this.groupBox11.Controls.Add(this.bntExibirConsulta);
            this.groupBox11.Controls.Add(this.cbConsultas);
            this.groupBox11.Location = new System.Drawing.Point(735, 84);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(185, 306);
            this.groupBox11.TabIndex = 17;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Consultas";
            // 
            // metroLabel28
            // 
            this.metroLabel28.AutoSize = true;
            this.metroLabel28.Location = new System.Drawing.Point(6, 45);
            this.metroLabel28.Name = "metroLabel28";
            this.metroLabel28.Size = new System.Drawing.Size(176, 19);
            this.metroLabel28.TabIndex = 11;
            this.metroLabel28.Text = "Selecione o tipo de consulta:";
            // 
            // bntExibirConsulta
            // 
            this.bntExibirConsulta.ActiveControl = null;
            this.bntExibirConsulta.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bntExibirConsulta.Location = new System.Drawing.Point(28, 160);
            this.bntExibirConsulta.Name = "bntExibirConsulta";
            this.bntExibirConsulta.Size = new System.Drawing.Size(133, 104);
            this.bntExibirConsulta.Style = MetroFramework.MetroColorStyle.Red;
            this.bntExibirConsulta.TabIndex = 7;
            this.bntExibirConsulta.Text = "Exibir/Atualizar\r\nConsulta";
            this.bntExibirConsulta.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bntExibirConsulta.Theme = MetroFramework.MetroThemeStyle.Light;
            this.bntExibirConsulta.UseSelectable = true;
            this.bntExibirConsulta.Click += new System.EventHandler(this.bntExibirConsulta_Click);
            // 
            // cbConsultas
            // 
            this.cbConsultas.FormattingEnabled = true;
            this.cbConsultas.ItemHeight = 23;
            this.cbConsultas.Items.AddRange(new object[] {
            "Todos Pedidos",
            "Pedidos por Cliente",
            "Custo por dia"});
            this.cbConsultas.Location = new System.Drawing.Point(28, 68);
            this.cbConsultas.Name = "cbConsultas";
            this.cbConsultas.Size = new System.Drawing.Size(133, 29);
            this.cbConsultas.TabIndex = 0;
            this.cbConsultas.UseSelectable = true;
            this.cbConsultas.SelectedIndexChanged += new System.EventHandler(this.cbConsultas_SelectedIndexChanged);
            // 
            // groupBox13
            // 
            this.groupBox13.BackColor = System.Drawing.Color.Transparent;
            this.groupBox13.Controls.Add(this.groupBox14);
            this.groupBox13.Controls.Add(this.txtPedidos);
            this.groupBox13.Controls.Add(this.metroLabel7);
            this.groupBox13.Controls.Add(this.bntProcurarPedido);
            this.groupBox13.Location = new System.Drawing.Point(58, 394);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(862, 105);
            this.groupBox13.TabIndex = 16;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Opção Pedidos";
            // 
            // groupBox14
            // 
            this.groupBox14.BackColor = System.Drawing.Color.Transparent;
            this.groupBox14.Controls.Add(this.pictureBox12);
            this.groupBox14.Controls.Add(this.pictureBox13);
            this.groupBox14.Controls.Add(this.bntImprimir);
            this.groupBox14.Controls.Add(this.bntVisualizaImp);
            this.groupBox14.Location = new System.Drawing.Point(6, 45);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(676, 54);
            this.groupBox14.TabIndex = 17;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Impressão";
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox12.Image")));
            this.pictureBox12.Location = new System.Drawing.Point(474, 10);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(47, 44);
            this.pictureBox12.TabIndex = 16;
            this.pictureBox12.TabStop = false;
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox13.Image")));
            this.pictureBox13.Location = new System.Drawing.Point(81, 13);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(38, 37);
            this.pictureBox13.TabIndex = 15;
            this.pictureBox13.TabStop = false;
            // 
            // bntImprimir
            // 
            this.bntImprimir.Location = new System.Drawing.Point(532, 11);
            this.bntImprimir.Name = "bntImprimir";
            this.bntImprimir.Size = new System.Drawing.Size(133, 37);
            this.bntImprimir.TabIndex = 14;
            this.bntImprimir.Text = "Imprimir";
            this.bntImprimir.UseSelectable = true;
            this.bntImprimir.Click += new System.EventHandler(this.bntImprimir_Click);
            // 
            // bntVisualizaImp
            // 
            this.bntVisualizaImp.Location = new System.Drawing.Point(125, 13);
            this.bntVisualizaImp.Name = "bntVisualizaImp";
            this.bntVisualizaImp.Size = new System.Drawing.Size(161, 37);
            this.bntVisualizaImp.TabIndex = 13;
            this.bntVisualizaImp.Text = "Visualizar Impressão";
            this.bntVisualizaImp.UseSelectable = true;
            this.bntVisualizaImp.Click += new System.EventHandler(this.bntVisualizaImp_Click);
            // 
            // txtPedidos
            // 
            this.txtPedidos.Lines = new string[0];
            this.txtPedidos.Location = new System.Drawing.Point(131, 19);
            this.txtPedidos.MaxLength = 32767;
            this.txtPedidos.Name = "txtPedidos";
            this.txtPedidos.PasswordChar = '\0';
            this.txtPedidos.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtPedidos.SelectedText = "";
            this.txtPedidos.Size = new System.Drawing.Size(540, 23);
            this.txtPedidos.TabIndex = 11;
            this.txtPedidos.UseSelectable = true;
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.Location = new System.Drawing.Point(14, 19);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(111, 19);
            this.metroLabel7.TabIndex = 10;
            this.metroLabel7.Text = "Procurar pedidos";
            // 
            // bntProcurarPedido
            // 
            this.bntProcurarPedido.Location = new System.Drawing.Point(705, 19);
            this.bntProcurarPedido.Name = "bntProcurarPedido";
            this.bntProcurarPedido.Size = new System.Drawing.Size(133, 74);
            this.bntProcurarPedido.TabIndex = 12;
            this.bntProcurarPedido.Text = "Procurar";
            this.bntProcurarPedido.UseSelectable = true;
            this.bntProcurarPedido.Click += new System.EventHandler(this.bntProPedidos_Click);
            // 
            // groupBox9
            // 
            this.groupBox9.BackColor = System.Drawing.Color.Transparent;
            this.groupBox9.Controls.Add(this.groupBox8);
            this.groupBox9.Controls.Add(this.txtProPedidos);
            this.groupBox9.Controls.Add(this.metroLabel26);
            this.groupBox9.Controls.Add(this.bntProPedidos);
            this.groupBox9.Location = new System.Drawing.Point(58, 394);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(862, 105);
            this.groupBox9.TabIndex = 16;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Opção Pedidos";
            // 
            // groupBox8
            // 
            this.groupBox8.BackColor = System.Drawing.Color.Transparent;
            this.groupBox8.Controls.Add(this.radialMenu1);
            this.groupBox8.Controls.Add(this.pictureBox11);
            this.groupBox8.Controls.Add(this.pictureBox10);
            this.groupBox8.Controls.Add(this.metroButton2);
            this.groupBox8.Controls.Add(this.metroButton1);
            this.groupBox8.Location = new System.Drawing.Point(6, 45);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(850, 54);
            this.groupBox8.TabIndex = 17;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Impressão";
            // 
            // radialMenu1
            // 
            this.radialMenu1.BackColor = System.Drawing.Color.Transparent;
            this.radialMenu1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            // 
            // 
            // 
            this.radialMenu1.Colors.CircularBackColor = System.Drawing.Color.Yellow;
            this.radialMenu1.Colors.CircularBorderColor = System.Drawing.Color.LightGray;
            this.radialMenu1.Colors.CircularForeColor = System.Drawing.Color.Transparent;
            this.radialMenu1.Colors.RadialMenuBackground = System.Drawing.Color.White;
            this.radialMenu1.Colors.RadialMenuBorder = System.Drawing.Color.Transparent;
            this.radialMenu1.Colors.RadialMenuButtonBackground = System.Drawing.Color.Transparent;
            this.radialMenu1.Colors.RadialMenuButtonBorder = System.Drawing.Color.Silver;
            this.radialMenu1.Colors.RadialMenuExpandForeground = System.Drawing.Color.Transparent;
            this.radialMenu1.Colors.RadialMenuInactiveBorder = System.Drawing.Color.LightGray;
            this.radialMenu1.Colors.RadialMenuItemForeground = System.Drawing.Color.Silver;
            this.radialMenu1.Colors.RadialMenuItemMouseOverBackground = System.Drawing.Color.Silver;
            this.radialMenu1.Colors.RadialMenuItemMouseOverForeground = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.radialMenu1.Colors.RadialMenuMouseOverBorder = System.Drawing.Color.Lime;
            this.radialMenu1.Items.AddRange(new DevComponents.DotNetBar.BaseItem[] {
            this.itsAdicionar,
            this.itsAlterar,
            this.itsRemover,
            this.itsCal});
            this.radialMenu1.Location = new System.Drawing.Point(417, 19);
            this.radialMenu1.Name = "radialMenu1";
            this.radialMenu1.Size = new System.Drawing.Size(28, 28);
            this.radialMenu1.SubMenuEdgeWidth = 8;
            this.radialMenu1.Symbol = "";
            this.radialMenu1.SymbolSize = 13F;
            this.radialMenu1.TabIndex = 71;
            this.radialMenu1.Text = "radialMenu2";
            // 
            // itsAdicionar
            // 
            this.itsAdicionar.Image = ((System.Drawing.Image)(resources.GetObject("itsAdicionar.Image")));
            this.itsAdicionar.Name = "itsAdicionar";
            this.itsAdicionar.Tooltip = "Adicionar";
            // 
            // itsAlterar
            // 
            this.itsAlterar.Image = ((System.Drawing.Image)(resources.GetObject("itsAlterar.Image")));
            this.itsAlterar.Name = "itsAlterar";
            this.itsAlterar.Tooltip = "Alterar";
            // 
            // itsRemover
            // 
            this.itsRemover.Image = ((System.Drawing.Image)(resources.GetObject("itsRemover.Image")));
            this.itsRemover.Name = "itsRemover";
            this.itsRemover.Tooltip = "Remover";
            // 
            // itsCal
            // 
            this.itsCal.Image = ((System.Drawing.Image)(resources.GetObject("itsCal.Image")));
            this.itsCal.Name = "itsCal";
            this.itsCal.Tooltip = "Calculadora";
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox11.Image")));
            this.pictureBox11.Location = new System.Drawing.Point(618, 6);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(47, 44);
            this.pictureBox11.TabIndex = 16;
            this.pictureBox11.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox10.Image")));
            this.pictureBox10.Location = new System.Drawing.Point(81, 17);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(38, 37);
            this.pictureBox10.TabIndex = 15;
            this.pictureBox10.TabStop = false;
            // 
            // metroButton2
            // 
            this.metroButton2.Location = new System.Drawing.Point(671, 10);
            this.metroButton2.Name = "metroButton2";
            this.metroButton2.Size = new System.Drawing.Size(161, 37);
            this.metroButton2.TabIndex = 14;
            this.metroButton2.Text = "Imprimir";
            this.metroButton2.UseSelectable = true;
            // 
            // metroButton1
            // 
            this.metroButton1.Location = new System.Drawing.Point(125, 13);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(161, 37);
            this.metroButton1.TabIndex = 13;
            this.metroButton1.Text = "Visualizar Impressão";
            this.metroButton1.UseSelectable = true;
            // 
            // txtProPedidos
            // 
            this.txtProPedidos.Lines = new string[0];
            this.txtProPedidos.Location = new System.Drawing.Point(131, 19);
            this.txtProPedidos.MaxLength = 32767;
            this.txtProPedidos.Name = "txtProPedidos";
            this.txtProPedidos.PasswordChar = '\0';
            this.txtProPedidos.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtProPedidos.SelectedText = "";
            this.txtProPedidos.Size = new System.Drawing.Size(540, 23);
            this.txtProPedidos.TabIndex = 11;
            this.txtProPedidos.UseSelectable = true;
            // 
            // metroLabel26
            // 
            this.metroLabel26.AutoSize = true;
            this.metroLabel26.Location = new System.Drawing.Point(14, 19);
            this.metroLabel26.Name = "metroLabel26";
            this.metroLabel26.Size = new System.Drawing.Size(111, 19);
            this.metroLabel26.TabIndex = 10;
            this.metroLabel26.Text = "Procurar pedidos";
            // 
            // bntProPedidos
            // 
            this.bntProPedidos.Location = new System.Drawing.Point(705, 19);
            this.bntProPedidos.Name = "bntProPedidos";
            this.bntProPedidos.Size = new System.Drawing.Size(133, 23);
            this.bntProPedidos.TabIndex = 12;
            this.bntProPedidos.Text = "Procurar";
            this.bntProPedidos.UseSelectable = true;
            this.bntProPedidos.Click += new System.EventHandler(this.bntProPedidos_Click);
            // 
            // htmlLabel1
            // 
            this.htmlLabel1.AutoScroll = true;
            this.htmlLabel1.AutoScrollMinSize = new System.Drawing.Size(302, 48);
            this.htmlLabel1.AutoSize = false;
            this.htmlLabel1.BackColor = System.Drawing.SystemColors.Window;
            this.htmlLabel1.Location = new System.Drawing.Point(322, 16);
            this.htmlLabel1.Name = "htmlLabel1";
            this.htmlLabel1.Size = new System.Drawing.Size(321, 52);
            this.htmlLabel1.TabIndex = 13;
            this.htmlLabel1.Text = "Pedidos Realizados";
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox9.Image = global::PizzariaMania.Properties.Resources.Contacts_icon;
            this.pictureBox9.Location = new System.Drawing.Point(252, 4);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(64, 64);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox9.TabIndex = 14;
            this.pictureBox9.TabStop = false;
            // 
            // tbPedidosRealizados
            // 
            this.tbPedidosRealizados.AttachedControl = this.tabControlPanel5;
            this.tbPedidosRealizados.Name = "tbPedidosRealizados";
            this.tbPedidosRealizados.Text = "Pedidos Realizados";
            // 
            // tabControlPanel7
            // 
            this.tabControlPanel7.Controls.Add(this.groupBox18);
            this.tabControlPanel7.Controls.Add(this.groupBox17);
            this.tabControlPanel7.Controls.Add(this.pictureBox15);
            this.tabControlPanel7.Controls.Add(this.htmlLabel3);
            this.tabControlPanel7.DisabledBackColor = System.Drawing.Color.Empty;
            this.tabControlPanel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlPanel7.Location = new System.Drawing.Point(0, 26);
            this.tabControlPanel7.Name = "tabControlPanel7";
            this.tabControlPanel7.Padding = new System.Windows.Forms.Padding(1);
            this.tabControlPanel7.Size = new System.Drawing.Size(970, 502);
            this.tabControlPanel7.Style.BackColor1.Color = System.Drawing.SystemColors.Control;
            this.tabControlPanel7.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.tabControlPanel7.Style.BorderSide = ((DevComponents.DotNetBar.eBorderSide)(((DevComponents.DotNetBar.eBorderSide.Left | DevComponents.DotNetBar.eBorderSide.Right)
                        | DevComponents.DotNetBar.eBorderSide.Bottom)));
            this.tabControlPanel7.Style.GradientAngle = 90;
            this.tabControlPanel7.TabIndex = 4;
            this.tabControlPanel7.TabItem = this.tbRegistro;
            this.tabControlPanel7.ThemeAware = true;
            // 
            // groupBox18
            // 
            this.groupBox18.BackColor = System.Drawing.Color.Transparent;
            this.groupBox18.Controls.Add(this.bntRemover);
            this.groupBox18.Location = new System.Drawing.Point(728, 119);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(185, 306);
            this.groupBox18.TabIndex = 22;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "Consultas";
            // 
            // bntRemover
            // 
            this.bntRemover.ActiveControl = null;
            this.bntRemover.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bntRemover.Location = new System.Drawing.Point(28, 104);
            this.bntRemover.Name = "bntRemover";
            this.bntRemover.Size = new System.Drawing.Size(133, 104);
            this.bntRemover.Style = MetroFramework.MetroColorStyle.Silver;
            this.bntRemover.TabIndex = 7;
            this.bntRemover.Text = "Atualizar";
            this.bntRemover.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bntRemover.Theme = MetroFramework.MetroThemeStyle.Light;
            this.bntRemover.UseSelectable = true;
            this.bntRemover.Click += new System.EventHandler(this.bntRemover_Click);
            // 
            // groupBox17
            // 
            this.groupBox17.BackColor = System.Drawing.Color.Transparent;
            this.groupBox17.Controls.Add(this.lblAvisoRegistro);
            this.groupBox17.Controls.Add(this.dgvAcesso);
            this.groupBox17.Location = new System.Drawing.Point(40, 119);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(677, 306);
            this.groupBox17.TabIndex = 21;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "Exibição de Pedidos";
            // 
            // lblAvisoRegistro
            // 
            this.lblAvisoRegistro.AutoSize = true;
            this.lblAvisoRegistro.BackColor = System.Drawing.Color.Transparent;
            this.lblAvisoRegistro.Location = new System.Drawing.Point(197, 149);
            this.lblAvisoRegistro.Name = "lblAvisoRegistro";
            this.lblAvisoRegistro.Size = new System.Drawing.Size(300, 13);
            this.lblAvisoRegistro.TabIndex = 23;
            this.lblAvisoRegistro.Text = "Você não tem permissão de visualizar os registros de acessos.";
            // 
            // dgvAcesso
            // 
            this.dgvAcesso.AllowUserToOrderColumns = true;
            this.dgvAcesso.AllowUserToResizeRows = false;
            this.dgvAcesso.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvAcesso.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvAcesso.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvAcesso.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(85)))), ((int)(((byte)(85)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvAcesso.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dgvAcesso.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvAcesso.DefaultCellStyle = dataGridViewCellStyle8;
            this.dgvAcesso.EnableHeadersVisualStyles = false;
            this.dgvAcesso.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvAcesso.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvAcesso.Location = new System.Drawing.Point(14, 23);
            this.dgvAcesso.Name = "dgvAcesso";
            this.dgvAcesso.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(85)))), ((int)(((byte)(85)))), ((int)(((byte)(85)))));
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(102)))), ((int)(((byte)(102)))));
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvAcesso.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.dgvAcesso.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvAcesso.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvAcesso.Size = new System.Drawing.Size(643, 259);
            this.dgvAcesso.Style = MetroFramework.MetroColorStyle.Silver;
            this.dgvAcesso.TabIndex = 68;
            // 
            // pictureBox15
            // 
            this.pictureBox15.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox15.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox15.Image")));
            this.pictureBox15.Location = new System.Drawing.Point(240, 30);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(48, 48);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox15.TabIndex = 20;
            this.pictureBox15.TabStop = false;
            // 
            // htmlLabel3
            // 
            this.htmlLabel3.AutoScroll = true;
            this.htmlLabel3.AutoScrollMinSize = new System.Drawing.Size(296, 48);
            this.htmlLabel3.AutoSize = false;
            this.htmlLabel3.BackColor = System.Drawing.SystemColors.Window;
            this.htmlLabel3.Location = new System.Drawing.Point(305, 30);
            this.htmlLabel3.Name = "htmlLabel3";
            this.htmlLabel3.Size = new System.Drawing.Size(478, 52);
            this.htmlLabel3.TabIndex = 19;
            this.htmlLabel3.Text = "Registro de Acesso";
            this.htmlLabel3.Click += new System.EventHandler(this.htmlLabel3_Click);
            // 
            // tbRegistro
            // 
            this.tbRegistro.AttachedControl = this.tabControlPanel7;
            this.tbRegistro.Name = "tbRegistro";
            this.tbRegistro.Text = "Registro de Acesso";
            // 
            // metroDateTime1
            // 
            this.metroDateTime1.Location = new System.Drawing.Point(20, 295);
            this.metroDateTime1.MinimumSize = new System.Drawing.Size(4, 29);
            this.metroDateTime1.Name = "metroDateTime1";
            this.metroDateTime1.Size = new System.Drawing.Size(267, 29);
            this.metroDateTime1.TabIndex = 18;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // tabControl1
            // 
            this.tabControl1.BackColor = System.Drawing.Color.Transparent;
            this.tabControl1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabControl1.CanReorderTabs = true;
            this.tabControl1.ColorScheme.TabBorder = System.Drawing.Color.Gray;
            this.tabControl1.ColorScheme.TabItemBackgroundColorBlend.AddRange(new DevComponents.DotNetBar.BackgroundColorBlend[] {
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.Empty, 0F),
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.Empty, 0.45F),
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.Empty, 0.45F),
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.Empty, 1F)});
            this.tabControl1.ColorScheme.TabItemHotBackgroundColorBlend.AddRange(new DevComponents.DotNetBar.BackgroundColorBlend[] {
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.Empty, 0F),
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.Empty, 0.45F),
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.Empty, 0.45F),
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.Empty, 1F)});
            this.tabControl1.ColorScheme.TabItemHotText = System.Drawing.Color.Black;
            this.tabControl1.ColorScheme.TabItemSelectedBackgroundColorBlend.AddRange(new DevComponents.DotNetBar.BackgroundColorBlend[] {
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.Empty, 0F),
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.Empty, 0.45F),
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.Empty, 0.45F),
            new DevComponents.DotNetBar.BackgroundColorBlend(System.Drawing.Color.Empty, 1F)});
            this.tabControl1.ColorScheme.TabItemSelectedText = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.tabControl1.Controls.Add(this.tabControlPanel2);
            this.tabControl1.Controls.Add(this.tabControlPanel1);
            this.tabControl1.Controls.Add(this.tabControlPanel3);
            this.tabControl1.ForeColor = System.Drawing.Color.Black;
            this.tabControl1.Location = new System.Drawing.Point(20, 98);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedTabFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.tabControl1.SelectedTabIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(267, 191);
            this.tabControl1.Style = DevComponents.DotNetBar.eTabStripStyle.Office2003;
            this.tabControl1.TabIndex = 21;
            this.tabControl1.TabLayoutType = DevComponents.DotNetBar.eTabLayoutType.FixedWithNavigationBox;
            this.tabControl1.Tabs.Add(this.tabItem1);
            this.tabControl1.Tabs.Add(this.tabItem2);
            this.tabControl1.Tabs.Add(this.tabItem3);
            this.tabControl1.Text = "Relatórios";
            this.tabControl1.ThemeAware = true;
            // 
            // tabControlPanel1
            // 
            this.tabControlPanel1.Controls.Add(this.groupBox2);
            this.tabControlPanel1.Controls.Add(this.groupBox1);
            this.tabControlPanel1.DisabledBackColor = System.Drawing.Color.Empty;
            this.tabControlPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlPanel1.Location = new System.Drawing.Point(0, 26);
            this.tabControlPanel1.Name = "tabControlPanel1";
            this.tabControlPanel1.Padding = new System.Windows.Forms.Padding(1);
            this.tabControlPanel1.Size = new System.Drawing.Size(267, 165);
            this.tabControlPanel1.Style.BackColor1.Color = System.Drawing.SystemColors.Control;
            this.tabControlPanel1.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.tabControlPanel1.Style.BorderSide = ((DevComponents.DotNetBar.eBorderSide)(((DevComponents.DotNetBar.eBorderSide.Left | DevComponents.DotNetBar.eBorderSide.Right)
                        | DevComponents.DotNetBar.eBorderSide.Bottom)));
            this.tabControlPanel1.Style.GradientAngle = 90;
            this.tabControlPanel1.TabIndex = 1;
            this.tabControlPanel1.TabItem = this.tabItem1;
            this.tabControlPanel1.ThemeAware = true;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.bntOpAtualizar);
            this.groupBox2.Controls.Add(this.bntOpSair);
            this.groupBox2.Controls.Add(this.bntOpLimpar);
            this.groupBox2.Controls.Add(this.bntOpFiltrar);
            this.groupBox2.Location = new System.Drawing.Point(134, 9);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(117, 137);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Opções";
            // 
            // bntOpAtualizar
            // 
            this.bntOpAtualizar.Location = new System.Drawing.Point(6, 18);
            this.bntOpAtualizar.Name = "bntOpAtualizar";
            this.bntOpAtualizar.Size = new System.Drawing.Size(97, 23);
            this.bntOpAtualizar.TabIndex = 10;
            this.bntOpAtualizar.Text = "Atualizar";
            this.bntOpAtualizar.UseSelectable = true;
            this.bntOpAtualizar.Click += new System.EventHandler(this.bntOpAtualizar_Click);
            // 
            // bntOpSair
            // 
            this.bntOpSair.Location = new System.Drawing.Point(6, 105);
            this.bntOpSair.Name = "bntOpSair";
            this.bntOpSair.Size = new System.Drawing.Size(97, 23);
            this.bntOpSair.Style = MetroFramework.MetroColorStyle.Green;
            this.bntOpSair.TabIndex = 13;
            this.bntOpSair.Text = "Sair";
            this.bntOpSair.UseSelectable = true;
            this.bntOpSair.Click += new System.EventHandler(this.bntOpSair_Click);
            // 
            // bntOpLimpar
            // 
            this.bntOpLimpar.Location = new System.Drawing.Point(6, 47);
            this.bntOpLimpar.Name = "bntOpLimpar";
            this.bntOpLimpar.Size = new System.Drawing.Size(97, 23);
            this.bntOpLimpar.TabIndex = 11;
            this.bntOpLimpar.Text = "Limpar";
            this.bntOpLimpar.UseSelectable = true;
            this.bntOpLimpar.Click += new System.EventHandler(this.bntOpLimpar_Click);
            // 
            // bntOpFiltrar
            // 
            this.bntOpFiltrar.Location = new System.Drawing.Point(6, 76);
            this.bntOpFiltrar.Name = "bntOpFiltrar";
            this.bntOpFiltrar.Size = new System.Drawing.Size(97, 23);
            this.bntOpFiltrar.TabIndex = 12;
            this.bntOpFiltrar.Text = "Filtrar";
            this.bntOpFiltrar.UseSelectable = true;
            this.bntOpFiltrar.Click += new System.EventHandler(this.bntOpFiltrar_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.metroButton3);
            this.groupBox1.Controls.Add(this.bntVerPerfil);
            this.groupBox1.Controls.Add(this.bntPedidos);
            this.groupBox1.Controls.Add(this.bntRelatorios);
            this.groupBox1.Location = new System.Drawing.Point(4, 9);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(129, 137);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Acesso Rápido";
            // 
            // metroButton3
            // 
            this.metroButton3.Location = new System.Drawing.Point(16, 18);
            this.metroButton3.Name = "metroButton3";
            this.metroButton3.Size = new System.Drawing.Size(97, 23);
            this.metroButton3.TabIndex = 14;
            this.metroButton3.Text = "Clientes";
            this.metroButton3.UseSelectable = true;
            this.metroButton3.Click += new System.EventHandler(this.metroButton3_Click);
            // 
            // bntVerPerfil
            // 
            this.bntVerPerfil.Location = new System.Drawing.Point(16, 105);
            this.bntVerPerfil.Name = "bntVerPerfil";
            this.bntVerPerfil.Size = new System.Drawing.Size(97, 23);
            this.bntVerPerfil.TabIndex = 17;
            this.bntVerPerfil.Text = "Ver perfil";
            this.bntVerPerfil.UseSelectable = true;
            this.bntVerPerfil.Click += new System.EventHandler(this.bntVerPerfil_Click);
            // 
            // bntPedidos
            // 
            this.bntPedidos.Location = new System.Drawing.Point(16, 47);
            this.bntPedidos.Name = "bntPedidos";
            this.bntPedidos.Size = new System.Drawing.Size(97, 23);
            this.bntPedidos.TabIndex = 15;
            this.bntPedidos.Text = "Pedidos";
            this.bntPedidos.UseSelectable = true;
            this.bntPedidos.Click += new System.EventHandler(this.bntPedidos_Click);
            // 
            // bntRelatorios
            // 
            this.bntRelatorios.Location = new System.Drawing.Point(16, 76);
            this.bntRelatorios.Name = "bntRelatorios";
            this.bntRelatorios.Size = new System.Drawing.Size(97, 23);
            this.bntRelatorios.TabIndex = 16;
            this.bntRelatorios.Text = "Relatórios";
            this.bntRelatorios.UseSelectable = true;
            this.bntRelatorios.Click += new System.EventHandler(this.bntPreco_Click);
            // 
            // tabItem1
            // 
            this.tabItem1.AttachedControl = this.tabControlPanel1;
            this.tabItem1.Name = "tabItem1";
            this.tabItem1.Text = "Opção Menu";
            // 
            // tabControlPanel2
            // 
            this.tabControlPanel2.Controls.Add(this.pictureBox7);
            this.tabControlPanel2.Controls.Add(this.bntPedidosRealizados);
            this.tabControlPanel2.Controls.Add(this.bntRelatorioPizza);
            this.tabControlPanel2.Controls.Add(this.bntRegistro);
            this.tabControlPanel2.DisabledBackColor = System.Drawing.Color.Empty;
            this.tabControlPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlPanel2.Location = new System.Drawing.Point(0, 26);
            this.tabControlPanel2.Name = "tabControlPanel2";
            this.tabControlPanel2.Padding = new System.Windows.Forms.Padding(1);
            this.tabControlPanel2.Size = new System.Drawing.Size(267, 165);
            this.tabControlPanel2.Style.BackColor1.Color = System.Drawing.SystemColors.Control;
            this.tabControlPanel2.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.tabControlPanel2.Style.BorderSide = ((DevComponents.DotNetBar.eBorderSide)(((DevComponents.DotNetBar.eBorderSide.Left | DevComponents.DotNetBar.eBorderSide.Right)
                        | DevComponents.DotNetBar.eBorderSide.Bottom)));
            this.tabControlPanel2.Style.GradientAngle = 90;
            this.tabControlPanel2.TabIndex = 2;
            this.tabControlPanel2.TabItem = this.tabItem2;
            this.tabControlPanel2.ThemeAware = true;
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox7.Image = global::PizzariaMania.Properties.Resources.checklist_icon;
            this.pictureBox7.Location = new System.Drawing.Point(15, 27);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(89, 110);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 19;
            this.pictureBox7.TabStop = false;
            // 
            // bntPedidosRealizados
            // 
            this.bntPedidosRealizados.Location = new System.Drawing.Point(110, 27);
            this.bntPedidosRealizados.Name = "bntPedidosRealizados";
            this.bntPedidosRealizados.Size = new System.Drawing.Size(133, 23);
            this.bntPedidosRealizados.TabIndex = 18;
            this.bntPedidosRealizados.Text = "Pedidos Realizados";
            this.bntPedidosRealizados.UseSelectable = true;
            this.bntPedidosRealizados.Click += new System.EventHandler(this.metroButton14_Click);
            // 
            // bntRelatorioPizza
            // 
            this.bntRelatorioPizza.Location = new System.Drawing.Point(110, 71);
            this.bntRelatorioPizza.Name = "bntRelatorioPizza";
            this.bntRelatorioPizza.Size = new System.Drawing.Size(133, 23);
            this.bntRelatorioPizza.TabIndex = 6;
            this.bntRelatorioPizza.Text = "Tabela de Pizza";
            this.bntRelatorioPizza.UseSelectable = true;
            this.bntRelatorioPizza.Click += new System.EventHandler(this.bntRelatorioPizza_Click);
            // 
            // bntRegistro
            // 
            this.bntRegistro.Location = new System.Drawing.Point(110, 114);
            this.bntRegistro.Name = "bntRegistro";
            this.bntRegistro.Size = new System.Drawing.Size(133, 23);
            this.bntRegistro.TabIndex = 4;
            this.bntRegistro.Text = "Registro de Acesso";
            this.bntRegistro.UseSelectable = true;
            this.bntRegistro.Click += new System.EventHandler(this.bntRegistro_Click);
            // 
            // tabItem2
            // 
            this.tabItem2.AttachedControl = this.tabControlPanel2;
            this.tabItem2.Name = "tabItem2";
            this.tabItem2.Text = "Relatórios";
            // 
            // tabControlPanel3
            // 
            this.tabControlPanel3.Controls.Add(this.pictureBox8);
            this.tabControlPanel3.Controls.Add(this.frmSobre);
            this.tabControlPanel3.Controls.Add(this.bntAjuda);
            this.tabControlPanel3.Controls.Add(this.bntCaculadora);
            this.tabControlPanel3.DisabledBackColor = System.Drawing.Color.Empty;
            this.tabControlPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlPanel3.Location = new System.Drawing.Point(0, 26);
            this.tabControlPanel3.Name = "tabControlPanel3";
            this.tabControlPanel3.Padding = new System.Windows.Forms.Padding(1);
            this.tabControlPanel3.Size = new System.Drawing.Size(267, 165);
            this.tabControlPanel3.Style.BackColor1.Color = System.Drawing.SystemColors.Control;
            this.tabControlPanel3.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.tabControlPanel3.Style.BorderSide = ((DevComponents.DotNetBar.eBorderSide)(((DevComponents.DotNetBar.eBorderSide.Left | DevComponents.DotNetBar.eBorderSide.Right)
                        | DevComponents.DotNetBar.eBorderSide.Bottom)));
            this.tabControlPanel3.Style.GradientAngle = 90;
            this.tabControlPanel3.TabIndex = 3;
            this.tabControlPanel3.TabItem = this.tabItem3;
            this.tabControlPanel3.ThemeAware = true;
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox8.Image = global::PizzariaMania.Properties.Resources.Tools_icon;
            this.pictureBox8.Location = new System.Drawing.Point(15, 27);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(102, 110);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 20;
            this.pictureBox8.TabStop = false;
            // 
            // frmSobre
            // 
            this.frmSobre.Location = new System.Drawing.Point(133, 114);
            this.frmSobre.Name = "frmSobre";
            this.frmSobre.Size = new System.Drawing.Size(97, 23);
            this.frmSobre.TabIndex = 18;
            this.frmSobre.Text = "Sobre";
            this.frmSobre.UseSelectable = true;
            this.frmSobre.Click += new System.EventHandler(this.frmSobre_Click);
            // 
            // bntAjuda
            // 
            this.bntAjuda.Location = new System.Drawing.Point(133, 71);
            this.bntAjuda.Name = "bntAjuda";
            this.bntAjuda.Size = new System.Drawing.Size(97, 23);
            this.bntAjuda.TabIndex = 9;
            this.bntAjuda.Text = "Obter Ajuda";
            this.bntAjuda.UseSelectable = true;
            this.bntAjuda.Click += new System.EventHandler(this.bntAjuda_Click);
            // 
            // bntCaculadora
            // 
            this.bntCaculadora.Location = new System.Drawing.Point(133, 27);
            this.bntCaculadora.Name = "bntCaculadora";
            this.bntCaculadora.Size = new System.Drawing.Size(97, 23);
            this.bntCaculadora.TabIndex = 7;
            this.bntCaculadora.Text = "Calculadora";
            this.bntCaculadora.UseSelectable = true;
            this.bntCaculadora.Click += new System.EventHandler(this.bntCaculadora_Click);
            // 
            // tabItem3
            // 
            this.tabItem3.AttachedControl = this.tabControlPanel3;
            this.tabItem3.Name = "tabItem3";
            this.tabItem3.Text = "Ferramentas";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.lblMensagem);
            this.panel1.Controls.Add(this.lblStatus);
            this.panel1.Location = new System.Drawing.Point(20, 331);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(267, 258);
            this.panel1.TabIndex = 22;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(66, 126);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(119, 93);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 25;
            this.pictureBox3.TabStop = false;
            // 
            // lblMensagem
            // 
            this.lblMensagem.AutoSize = true;
            this.lblMensagem.Location = new System.Drawing.Point(14, 9);
            this.lblMensagem.Name = "lblMensagem";
            this.lblMensagem.Size = new System.Drawing.Size(248, 114);
            this.lblMensagem.TabIndex = 24;
            this.lblMensagem.Text = "Olá eu sou o chefinho,\r\nVou te ajudar oferecendo dicas, \r\nte alertando,e contando" +
                " algumas piadas,\r\nMas não se preocupe...\r\nPizzariaMania é fácil de mexe.\r\nMama M" +
                "ia.";
            // 
            // lblStatus
            // 
            this.lblStatus.ActiveControl = null;
            this.lblStatus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblStatus.Location = new System.Drawing.Point(-1, 225);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(267, 32);
            this.lblStatus.Style = MetroFramework.MetroColorStyle.Red;
            this.lblStatus.TabIndex = 23;
            this.lblStatus.Text = "Status";
            this.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblStatus.Theme = MetroFramework.MetroThemeStyle.Light;
            this.lblStatus.UseSelectable = true;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.lblTipoAcesso);
            this.groupBox10.Controls.Add(this.lblUsuario);
            this.groupBox10.Location = new System.Drawing.Point(20, 595);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(267, 60);
            this.groupBox10.TabIndex = 25;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Usuario";
            this.groupBox10.Enter += new System.EventHandler(this.groupBox10_Enter);
            // 
            // lblTipoAcesso
            // 
            this.lblTipoAcesso.AutoSize = true;
            this.lblTipoAcesso.Location = new System.Drawing.Point(35, 36);
            this.lblTipoAcesso.Name = "lblTipoAcesso";
            this.lblTipoAcesso.Size = new System.Drawing.Size(101, 19);
            this.lblTipoAcesso.TabIndex = 1;
            this.lblTipoAcesso.Text = "Tipo de Acesso:";
            this.lblTipoAcesso.Click += new System.EventHandler(this.lblTipoAcesso_Click);
            // 
            // lblUsuario
            // 
            this.lblUsuario.AutoSize = true;
            this.lblUsuario.Location = new System.Drawing.Point(35, 17);
            this.lblUsuario.Name = "lblUsuario";
            this.lblUsuario.Size = new System.Drawing.Size(56, 19);
            this.lblUsuario.TabIndex = 0;
            this.lblUsuario.Text = "Usuario:";
            this.lblUsuario.Click += new System.EventHandler(this.lblUsuario_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(20, 707);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1319, 45);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // printDlg
            // 
            this.printDlg.Document = this.printDoc;
            this.printDlg.UseEXDialog = true;
            // 
            // printDoc
            // 
            this.printDoc.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDoc_PrintPage);
            // 
            // printPreview
            // 
            this.printPreview.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreview.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreview.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreview.Document = this.printDoc;
            this.printPreview.Enabled = true;
            this.printPreview.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreview.Icon")));
            this.printPreview.Name = "printPreview";
            this.printPreview.Visible = false;
            // 
            // frmSistema
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1359, 772);
            this.Controls.Add(this.groupBox10);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.metroDateTime1);
            this.Controls.Add(this.mtpGerenciador);
            this.Controls.Add(this.pictureBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Location = new System.Drawing.Point(0, 606);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmSistema";
            this.Style = MetroFramework.MetroColorStyle.Red;
            this.Text = "Gerenciador";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmSistema_Load);
            this.mtpGerenciador.ResumeLayout(false);
            this.tpClientes.ResumeLayout(false);
            this.tpClientes.PerformLayout();
            this.tbsClientes.ResumeLayout(false);
            this.mtpAdicionar.ResumeLayout(false);
            this.mtpAdicionar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.mtpAlterar.ResumeLayout(false);
            this.mtpAlterar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.mtpRemover.ResumeLayout(false);
            this.mtpRemover.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvClientes)).EndInit();
            this.tpPedidos.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.gbxTabela.ResumeLayout(false);
            this.gbxTabela.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPizzas)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.tbRelatorios.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tbMenuRelatorio)).EndInit();
            this.tbMenuRelatorio.ResumeLayout(false);
            this.tabControlPanel6.ResumeLayout(false);
            this.groupBox15.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPizzas2)).EndInit();
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            this.tabControlPanel5.ResumeLayout(false);
            this.tabControlPanel5.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPedidos)).EndInit();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            this.tabControlPanel7.ResumeLayout(false);
            this.tabControlPanel7.PerformLayout();
            this.groupBox18.ResumeLayout(false);
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAcesso)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tabControl1)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabControlPanel1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.tabControlPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.tabControlPanel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private MetroFramework.Controls.MetroTabControl mtpGerenciador;
        private MetroFramework.Controls.MetroTabPage tpClientes;
        private MetroFramework.Controls.MetroTabPage tpPedidos;
        private MetroFramework.Controls.MetroGrid dgvClientes;
        private MetroFramework.Controls.MetroDateTime metroDateTime1;
        private System.Windows.Forms.Timer timer1;
        private DevComponents.DotNetBar.TabControl tabControl1;
        private DevComponents.DotNetBar.TabControlPanel tabControlPanel1;
        private DevComponents.DotNetBar.TabItem tabItem1;
        private DevComponents.DotNetBar.TabControlPanel tabControlPanel3;
        private DevComponents.DotNetBar.TabItem tabItem3;
        private DevComponents.DotNetBar.TabControlPanel tabControlPanel2;
        private DevComponents.DotNetBar.TabItem tabItem2;
        private MetroFramework.Controls.MetroButton frmSobre;
        private MetroFramework.Controls.MetroButton bntAjuda;
        private MetroFramework.Controls.MetroButton bntCaculadora;
        private MetroFramework.Controls.MetroButton bntPedidosRealizados;
        private MetroFramework.Controls.MetroButton bntRelatorioPizza;
        private MetroFramework.Controls.MetroButton bntRegistro;
        private MetroFramework.Controls.MetroButton bntVerPerfil;
        private MetroFramework.Controls.MetroButton bntRelatorios;
        private MetroFramework.Controls.MetroButton bntPedidos;
        private MetroFramework.Controls.MetroButton metroButton3;
        private System.Windows.Forms.Panel panel1;
        private MetroFramework.Controls.MetroTile lblStatus;
        private MetroFramework.Controls.MetroLabel lblMensagem;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.GroupBox groupBox2;
        private MetroFramework.Controls.MetroButton bntOpAtualizar;
        private MetroFramework.Controls.MetroButton bntOpSair;
        private MetroFramework.Controls.MetroButton bntOpLimpar;
        private MetroFramework.Controls.MetroButton bntOpFiltrar;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private MetroFramework.Controls.MetroTabPage tbRelatorios;
        private System.Windows.Forms.GroupBox groupBox3;
        private MetroFramework.Controls.MetroLabel metroLabel15;
        private MetroFramework.Controls.MetroTextBox txtCaixa;
        private MetroFramework.Controls.MetroTextBox txtDataPedido;
        private MetroFramework.Controls.MetroLabel metroLabel18;
        private MetroFramework.Controls.MetroLabel metroLabel16;
        private MetroFramework.Controls.MetroTextBox txtTelefonePedido;
        private MetroFramework.Controls.MetroTextBox txtCustoTotal;
        private MetroFramework.Controls.MetroLabel metroLabel17;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.GroupBox groupBox5;
        private MetroFramework.Controls.MetroLabel metroLabel21;
        private System.Windows.Forms.GroupBox gbxTabela;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.ListBox lbxItens;
        private MetroFramework.Controls.MetroTile bntAdicionarPedido;
        private MetroFramework.Controls.MetroLabel metroLabel22;
        private MetroFramework.Controls.MetroButton bntLimparItens;
        private MetroFramework.Controls.MetroTile bntIntesAdicionar;
        private MetroFramework.Controls.MetroTextBox txtInfoPedido;
        private MetroFramework.Controls.MetroTextBox txtSaborPedido;
        private MetroFramework.Controls.MetroLabel metroLabel24;
        private MetroFramework.Controls.MetroLabel metroLabel23;
        private MetroFramework.Controls.MetroLabel metroLabel19;
        private System.Windows.Forms.PictureBox pictureBox7;
        private MetroFramework.Controls.MetroButton bntFiltrar;
        private MetroFramework.Controls.MetroLabel lblFiltrarCadastro;
        private MetroFramework.Controls.MetroTextBox txtFiltar;
        private MetroFramework.Controls.MetroTabControl tbsClientes;
        private MetroFramework.Controls.MetroTabPage mtpAdicionar;
        private MetroFramework.Controls.MetroTile bntAdicionarCliente;
        private MetroFramework.Controls.MetroButton bntAdiLimparCliente;
        private System.Windows.Forms.PictureBox pictureBox2;
        private MetroFramework.Controls.MetroComboBox cbbAdiUFCliente;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroTextBox txtAdiCidadeCliente;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroTextBox txtAdiTelefoneCliente;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroTextBox txtAdiReferenciasCliente;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroTextBox txtAdiEnderecoCliente;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroTextBox txtAdiNomeCliente;
        private MetroFramework.Controls.MetroTabPage mtpAlterar;
        private MetroFramework.Controls.MetroTile bntAlteraCliente;
        private MetroFramework.Controls.MetroButton bntAltLimparCliente;
        private System.Windows.Forms.PictureBox pictureBox4;
        private MetroFramework.Controls.MetroComboBox cbbAltUfCliente;
        private MetroFramework.Controls.MetroLabel metroLabel9;
        private MetroFramework.Controls.MetroLabel metroLabel10;
        private MetroFramework.Controls.MetroTextBox txtAltCidadeCliente;
        private MetroFramework.Controls.MetroLabel metroLabel11;
        private MetroFramework.Controls.MetroTextBox txtAltTelefoneCliente;
        private MetroFramework.Controls.MetroLabel metroLabel12;
        private MetroFramework.Controls.MetroTextBox txtAltReferenciasCliente;
        private MetroFramework.Controls.MetroLabel metroLabel13;
        private MetroFramework.Controls.MetroTextBox txtAltEnderecoCliente;
        private MetroFramework.Controls.MetroLabel metroLabel14;
        private MetroFramework.Controls.MetroTextBox txtAltNomeCliente;
        private MetroFramework.Controls.MetroTabPage mtpRemover;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private MetroFramework.Controls.MetroTextBox txtExcNomeCliente;
        private MetroFramework.Controls.MetroTile bntExluirCliente;
        private System.Windows.Forms.PictureBox pictureBox5;
        private MetroFramework.Controls.MetroLabel metroLabel20;
        private MetroFramework.Controls.MetroTextBox txtExcIdCliente;
        private MetroFramework.Controls.MetroTile bntCancelarPedidos;
        private MetroFramework.Controls.MetroGrid dgvPizzas;
        private MetroFramework.Controls.MetroLabel metroLabel25;
        private DevComponents.DotNetBar.TabControl tbMenuRelatorio;
        private DevComponents.DotNetBar.TabControlPanel tabControlPanel5;
        private DevComponents.DotNetBar.TabItem tbPedidosRealizados;
        private DevComponents.DotNetBar.TabControlPanel tabControlPanel6;
        private DevComponents.DotNetBar.TabItem tbTabelaPizza;
        private System.Windows.Forms.PictureBox pictureBox8;
        private DevComponents.DotNetBar.TabControlPanel tabControlPanel7;
        private DevComponents.DotNetBar.TabItem tbRegistro;
        private MetroFramework.Controls.MetroTextBox txtNomePedido;
        private MetroFramework.Controls.MetroButton bntProcuraCliente;
        private MetroFramework.Controls.MetroButton bntProPedidos;
        private MetroFramework.Controls.MetroLabel metroLabel26;
        private MetroFramework.Controls.MetroTextBox txtProPedidos;
        private MetroFramework.Controls.MetroLabel lblIdCliente;
        private MetroFramework.Drawing.Html.HtmlLabel htmlLabel1;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.RadioButton rbtGrandeP;
        private System.Windows.Forms.RadioButton rbtMediaP;
        private System.Windows.Forms.RadioButton rbtPequenaP;
        private DevComponents.DotNetBar.RadialMenuItem itsAdicionar;
        private DevComponents.DotNetBar.RadialMenuItem itsAlterar;
        private DevComponents.DotNetBar.RadialMenuItem itsRemover;
        private DevComponents.DotNetBar.RadialMenuItem itsCal;
        private MetroFramework.Controls.MetroButton bntEditar;
        private MetroFramework.Controls.MetroTextBox txtQuantidade;
        private System.Windows.Forms.Label lblTesteListBox;
        private MetroFramework.Controls.MetroButton bntRemoverItens;
        private MetroFramework.Controls.MetroButton bntAtualizaPizza;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox10;
        private MetroFramework.Controls.MetroButton metroButton2;
        private MetroFramework.Controls.MetroButton metroButton1;
        private System.Windows.Forms.Label lblPermissao;
        private System.Windows.Forms.GroupBox groupBox10;
        private MetroFramework.Controls.MetroLabel lblTipoAcesso;
        private MetroFramework.Controls.MetroLabel lblUsuario;
        private System.Windows.Forms.GroupBox groupBox11;
        private MetroFramework.Controls.MetroTile bntExibirConsulta;
        private MetroFramework.Controls.MetroComboBox cbConsultas;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox13;
        private MetroFramework.Controls.MetroButton bntImprimir;
        private MetroFramework.Controls.MetroButton bntVisualizaImp;
        private MetroFramework.Controls.MetroTextBox txtPedidos;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroButton bntProcurarPedido;
        private DevComponents.DotNetBar.RadialMenu radialMenu1;
        private MetroFramework.Controls.MetroLabel metroLabel28;
        private System.Windows.Forms.Label lblIDClienteTs;
        private System.Windows.Forms.GroupBox groupBox15;
        private MetroFramework.Controls.MetroGrid dgvPizzas2;
        private System.Windows.Forms.GroupBox groupBox16;
        private MetroFramework.Controls.MetroLabel metroLabel29;
        private MetroFramework.Controls.MetroTile bntPizzasEditar;
        private MetroFramework.Controls.MetroComboBox cbPizzaEditar;
        private System.Windows.Forms.PictureBox pictureBox14;
        private MetroFramework.Drawing.Html.HtmlLabel htmlLabel2;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.PictureBox pictureBox15;
        private MetroFramework.Drawing.Html.HtmlLabel htmlLabel3;
        private System.Windows.Forms.GroupBox groupBox18;
        private MetroFramework.Controls.MetroTile bntRemover;
        private MetroFramework.Controls.MetroGrid dgvAcesso;
        private MetroFramework.Controls.MetroGrid dgvPedidos;
        private System.Windows.Forms.Label lblAvisoRegistro;
        private System.Windows.Forms.PrintDialog printDlg;
        private System.Drawing.Printing.PrintDocument printDoc;
        private System.Windows.Forms.PrintPreviewDialog printPreview;
    }
}