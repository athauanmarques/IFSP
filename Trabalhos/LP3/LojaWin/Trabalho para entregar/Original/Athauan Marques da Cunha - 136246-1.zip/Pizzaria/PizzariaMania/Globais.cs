﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PizzariaMania
{
    class Globais
    {
        //Usuario e contador de tentativa
        public static string strUsuario;
        public static int intContador;

        public static int idCliente;
        public static string nomeProcura;
        public static string telefoneProcura;
        public static int opEditarPizza; //função para ativar o tipo de edição


        public static string IdUsuarioLogi;
        public static string tipoAcessoLogi = "Administrador";

        //Registro de Acesso
        public static string ultimoAcesso;
        
    }
}
