﻿namespace PizzariaMania
{
    partial class frmTabelaPreco
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTabelaPreco));
            this.tbMenuTabela = new MetroFramework.Controls.MetroTabControl();
            this.tpAdicionar = new MetroFramework.Controls.MetroTabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtAdiSabores = new MetroFramework.Controls.MetroTextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtAdiInfomacoes = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.txtAdiMedia = new MetroFramework.Controls.MetroTextBox();
            this.txtAdiPequena = new MetroFramework.Controls.MetroTextBox();
            this.txtAdiGrande = new MetroFramework.Controls.MetroTextBox();
            this.bntAdicionar = new MetroFramework.Controls.MetroTile();
            this.bntLimpar = new MetroFramework.Controls.MetroButton();
            this.tpAlterar = new MetroFramework.Controls.MetroTabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtAltSabor = new MetroFramework.Controls.MetroTextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.txtAltInformacoes = new System.Windows.Forms.TextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.txtAltMedia = new MetroFramework.Controls.MetroTextBox();
            this.txtAltPequena = new MetroFramework.Controls.MetroTextBox();
            this.txtAltGrande = new MetroFramework.Controls.MetroTextBox();
            this.bntAlterar = new MetroFramework.Controls.MetroTile();
            this.bntLimparAlterar = new MetroFramework.Controls.MetroButton();
            this.tbRemover = new MetroFramework.Controls.MetroTabPage();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.txtExcPizza = new MetroFramework.Controls.MetroTextBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.txtExcSabor = new MetroFramework.Controls.MetroTextBox();
            this.bntRemover = new MetroFramework.Controls.MetroTile();
            this.dgvPizzas = new MetroFramework.Controls.MetroGrid();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.tbMenuTabela.SuspendLayout();
            this.tpAdicionar.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tpAlterar.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.tbRemover.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPizzas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // tbMenuTabela
            // 
            this.tbMenuTabela.Controls.Add(this.tpAdicionar);
            this.tbMenuTabela.Controls.Add(this.tpAlterar);
            this.tbMenuTabela.Controls.Add(this.tbRemover);
            this.tbMenuTabela.Location = new System.Drawing.Point(55, 194);
            this.tbMenuTabela.Name = "tbMenuTabela";
            this.tbMenuTabela.SelectedIndex = 0;
            this.tbMenuTabela.Size = new System.Drawing.Size(372, 484);
            this.tbMenuTabela.Style = MetroFramework.MetroColorStyle.Red;
            this.tbMenuTabela.TabIndex = 73;
            this.tbMenuTabela.UseSelectable = true;
            // 
            // tpAdicionar
            // 
            this.tpAdicionar.Controls.Add(this.groupBox3);
            this.tpAdicionar.Controls.Add(this.groupBox2);
            this.tpAdicionar.Controls.Add(this.groupBox1);
            this.tpAdicionar.Controls.Add(this.bntAdicionar);
            this.tpAdicionar.Controls.Add(this.bntLimpar);
            this.tpAdicionar.HorizontalScrollbarBarColor = true;
            this.tpAdicionar.HorizontalScrollbarHighlightOnWheel = false;
            this.tpAdicionar.HorizontalScrollbarSize = 10;
            this.tpAdicionar.Location = new System.Drawing.Point(4, 38);
            this.tpAdicionar.Name = "tpAdicionar";
            this.tpAdicionar.Size = new System.Drawing.Size(364, 442);
            this.tpAdicionar.TabIndex = 0;
            this.tpAdicionar.Text = "Adicionar";
            this.tpAdicionar.VerticalScrollbarBarColor = true;
            this.tpAdicionar.VerticalScrollbarHighlightOnWheel = false;
            this.tpAdicionar.VerticalScrollbarSize = 10;
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.Transparent;
            this.groupBox3.Controls.Add(this.txtAdiSabores);
            this.groupBox3.Location = new System.Drawing.Point(33, 39);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(299, 56);
            this.groupBox3.TabIndex = 90;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Sabores";
            // 
            // txtAdiSabores
            // 
            this.txtAdiSabores.Lines = new string[0];
            this.txtAdiSabores.Location = new System.Drawing.Point(11, 17);
            this.txtAdiSabores.MaxLength = 32767;
            this.txtAdiSabores.Name = "txtAdiSabores";
            this.txtAdiSabores.PasswordChar = '\0';
            this.txtAdiSabores.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtAdiSabores.SelectedText = "";
            this.txtAdiSabores.Size = new System.Drawing.Size(282, 23);
            this.txtAdiSabores.TabIndex = 85;
            this.txtAdiSabores.UseSelectable = true;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.txtAdiInfomacoes);
            this.groupBox2.Location = new System.Drawing.Point(33, 228);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(299, 121);
            this.groupBox2.TabIndex = 71;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Informações";
            // 
            // txtAdiInfomacoes
            // 
            this.txtAdiInfomacoes.Location = new System.Drawing.Point(11, 19);
            this.txtAdiInfomacoes.Multiline = true;
            this.txtAdiInfomacoes.Name = "txtAdiInfomacoes";
            this.txtAdiInfomacoes.Size = new System.Drawing.Size(282, 82);
            this.txtAdiInfomacoes.TabIndex = 90;
            this.txtAdiInfomacoes.TextChanged += new System.EventHandler(this.txtAdiInfomacoes_TextChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.metroLabel4);
            this.groupBox1.Controls.Add(this.metroLabel3);
            this.groupBox1.Controls.Add(this.metroLabel5);
            this.groupBox1.Controls.Add(this.txtAdiMedia);
            this.groupBox1.Controls.Add(this.txtAdiPequena);
            this.groupBox1.Controls.Add(this.txtAdiGrande);
            this.groupBox1.Location = new System.Drawing.Point(33, 101);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(299, 121);
            this.groupBox1.TabIndex = 71;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Preços";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(67, 24);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(59, 19);
            this.metroLabel4.TabIndex = 81;
            this.metroLabel4.Text = "Pequena";
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(67, 57);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(46, 19);
            this.metroLabel3.TabIndex = 82;
            this.metroLabel3.Text = "Média";
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(67, 86);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(52, 19);
            this.metroLabel5.TabIndex = 83;
            this.metroLabel5.Text = "Grande";
            // 
            // txtAdiMedia
            // 
            this.txtAdiMedia.Lines = new string[0];
            this.txtAdiMedia.Location = new System.Drawing.Point(132, 53);
            this.txtAdiMedia.MaxLength = 32767;
            this.txtAdiMedia.Name = "txtAdiMedia";
            this.txtAdiMedia.PasswordChar = '\0';
            this.txtAdiMedia.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtAdiMedia.SelectedText = "";
            this.txtAdiMedia.Size = new System.Drawing.Size(98, 23);
            this.txtAdiMedia.TabIndex = 86;
            this.txtAdiMedia.UseSelectable = true;
            this.txtAdiMedia.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAdiPequena_KeyPress);
            // 
            // txtAdiPequena
            // 
            this.txtAdiPequena.Lines = new string[0];
            this.txtAdiPequena.Location = new System.Drawing.Point(132, 24);
            this.txtAdiPequena.MaxLength = 32767;
            this.txtAdiPequena.Name = "txtAdiPequena";
            this.txtAdiPequena.PasswordChar = '\0';
            this.txtAdiPequena.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtAdiPequena.SelectedText = "";
            this.txtAdiPequena.Size = new System.Drawing.Size(99, 23);
            this.txtAdiPequena.TabIndex = 87;
            this.txtAdiPequena.UseSelectable = true;
            this.txtAdiPequena.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAdiPequena_KeyPress);
            // 
            // txtAdiGrande
            // 
            this.txtAdiGrande.Lines = new string[0];
            this.txtAdiGrande.Location = new System.Drawing.Point(131, 82);
            this.txtAdiGrande.MaxLength = 32767;
            this.txtAdiGrande.Name = "txtAdiGrande";
            this.txtAdiGrande.PasswordChar = '\0';
            this.txtAdiGrande.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtAdiGrande.SelectedText = "";
            this.txtAdiGrande.Size = new System.Drawing.Size(99, 23);
            this.txtAdiGrande.TabIndex = 88;
            this.txtAdiGrande.UseSelectable = true;
            this.txtAdiGrande.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAdiPequena_KeyPress);
            // 
            // bntAdicionar
            // 
            this.bntAdicionar.ActiveControl = null;
            this.bntAdicionar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bntAdicionar.Location = new System.Drawing.Point(195, 355);
            this.bntAdicionar.Name = "bntAdicionar";
            this.bntAdicionar.Size = new System.Drawing.Size(111, 52);
            this.bntAdicionar.Style = MetroFramework.MetroColorStyle.Red;
            this.bntAdicionar.TabIndex = 72;
            this.bntAdicionar.Text = "Adicionar";
            this.bntAdicionar.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bntAdicionar.Theme = MetroFramework.MetroThemeStyle.Light;
            this.bntAdicionar.UseSelectable = true;
            this.bntAdicionar.Click += new System.EventHandler(this.bntAdicionar_Click);
            // 
            // bntLimpar
            // 
            this.bntLimpar.Location = new System.Drawing.Point(56, 355);
            this.bntLimpar.Name = "bntLimpar";
            this.bntLimpar.Size = new System.Drawing.Size(111, 52);
            this.bntLimpar.TabIndex = 73;
            this.bntLimpar.Text = "Limpar";
            this.bntLimpar.UseSelectable = true;
            this.bntLimpar.Click += new System.EventHandler(this.bntLimpar_Click);
            // 
            // tpAlterar
            // 
            this.tpAlterar.Controls.Add(this.groupBox4);
            this.tpAlterar.Controls.Add(this.groupBox5);
            this.tpAlterar.Controls.Add(this.groupBox6);
            this.tpAlterar.Controls.Add(this.bntAlterar);
            this.tpAlterar.Controls.Add(this.bntLimparAlterar);
            this.tpAlterar.HorizontalScrollbarBarColor = true;
            this.tpAlterar.HorizontalScrollbarHighlightOnWheel = false;
            this.tpAlterar.HorizontalScrollbarSize = 10;
            this.tpAlterar.Location = new System.Drawing.Point(4, 38);
            this.tpAlterar.Name = "tpAlterar";
            this.tpAlterar.Size = new System.Drawing.Size(364, 442);
            this.tpAlterar.TabIndex = 1;
            this.tpAlterar.Text = "Altera";
            this.tpAlterar.VerticalScrollbarBarColor = true;
            this.tpAlterar.VerticalScrollbarHighlightOnWheel = false;
            this.tpAlterar.VerticalScrollbarSize = 10;
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.Transparent;
            this.groupBox4.Controls.Add(this.txtAltSabor);
            this.groupBox4.Location = new System.Drawing.Point(33, 37);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(299, 56);
            this.groupBox4.TabIndex = 95;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Sabores";
            // 
            // txtAltSabor
            // 
            this.txtAltSabor.Lines = new string[0];
            this.txtAltSabor.Location = new System.Drawing.Point(11, 17);
            this.txtAltSabor.MaxLength = 32767;
            this.txtAltSabor.Name = "txtAltSabor";
            this.txtAltSabor.PasswordChar = '\0';
            this.txtAltSabor.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtAltSabor.SelectedText = "";
            this.txtAltSabor.Size = new System.Drawing.Size(282, 23);
            this.txtAltSabor.TabIndex = 85;
            this.txtAltSabor.UseSelectable = true;
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.Transparent;
            this.groupBox5.Controls.Add(this.txtAltInformacoes);
            this.groupBox5.Location = new System.Drawing.Point(33, 226);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(299, 121);
            this.groupBox5.TabIndex = 91;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Informações";
            // 
            // txtAltInformacoes
            // 
            this.txtAltInformacoes.Location = new System.Drawing.Point(11, 19);
            this.txtAltInformacoes.Multiline = true;
            this.txtAltInformacoes.Name = "txtAltInformacoes";
            this.txtAltInformacoes.Size = new System.Drawing.Size(282, 82);
            this.txtAltInformacoes.TabIndex = 90;
            // 
            // groupBox6
            // 
            this.groupBox6.BackColor = System.Drawing.Color.Transparent;
            this.groupBox6.Controls.Add(this.metroLabel1);
            this.groupBox6.Controls.Add(this.metroLabel2);
            this.groupBox6.Controls.Add(this.metroLabel6);
            this.groupBox6.Controls.Add(this.txtAltMedia);
            this.groupBox6.Controls.Add(this.txtAltPequena);
            this.groupBox6.Controls.Add(this.txtAltGrande);
            this.groupBox6.Location = new System.Drawing.Point(33, 99);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(299, 121);
            this.groupBox6.TabIndex = 92;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Preços";
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(67, 23);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(59, 19);
            this.metroLabel1.TabIndex = 81;
            this.metroLabel1.Text = "Pequena";
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(67, 56);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(46, 19);
            this.metroLabel2.TabIndex = 82;
            this.metroLabel2.Text = "Média";
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(67, 85);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(52, 19);
            this.metroLabel6.TabIndex = 83;
            this.metroLabel6.Text = "Grande";
            // 
            // txtAltMedia
            // 
            this.txtAltMedia.Lines = new string[0];
            this.txtAltMedia.Location = new System.Drawing.Point(132, 52);
            this.txtAltMedia.MaxLength = 32767;
            this.txtAltMedia.Name = "txtAltMedia";
            this.txtAltMedia.PasswordChar = '\0';
            this.txtAltMedia.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtAltMedia.SelectedText = "";
            this.txtAltMedia.Size = new System.Drawing.Size(98, 23);
            this.txtAltMedia.TabIndex = 86;
            this.txtAltMedia.UseSelectable = true;
            this.txtAltMedia.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAdiPequena_KeyPress);
            // 
            // txtAltPequena
            // 
            this.txtAltPequena.Lines = new string[0];
            this.txtAltPequena.Location = new System.Drawing.Point(132, 23);
            this.txtAltPequena.MaxLength = 32767;
            this.txtAltPequena.Name = "txtAltPequena";
            this.txtAltPequena.PasswordChar = '\0';
            this.txtAltPequena.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtAltPequena.SelectedText = "";
            this.txtAltPequena.Size = new System.Drawing.Size(99, 23);
            this.txtAltPequena.TabIndex = 87;
            this.txtAltPequena.UseSelectable = true;
            this.txtAltPequena.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAdiPequena_KeyPress);
            // 
            // txtAltGrande
            // 
            this.txtAltGrande.Lines = new string[0];
            this.txtAltGrande.Location = new System.Drawing.Point(131, 81);
            this.txtAltGrande.MaxLength = 32767;
            this.txtAltGrande.Name = "txtAltGrande";
            this.txtAltGrande.PasswordChar = '\0';
            this.txtAltGrande.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtAltGrande.SelectedText = "";
            this.txtAltGrande.Size = new System.Drawing.Size(99, 23);
            this.txtAltGrande.TabIndex = 88;
            this.txtAltGrande.UseSelectable = true;
            this.txtAltGrande.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAdiPequena_KeyPress);
            // 
            // bntAlterar
            // 
            this.bntAlterar.ActiveControl = null;
            this.bntAlterar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bntAlterar.Location = new System.Drawing.Point(206, 353);
            this.bntAlterar.Name = "bntAlterar";
            this.bntAlterar.Size = new System.Drawing.Size(111, 52);
            this.bntAlterar.Style = MetroFramework.MetroColorStyle.Red;
            this.bntAlterar.TabIndex = 93;
            this.bntAlterar.Text = "Alterar";
            this.bntAlterar.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bntAlterar.Theme = MetroFramework.MetroThemeStyle.Light;
            this.bntAlterar.UseSelectable = true;
            this.bntAlterar.Click += new System.EventHandler(this.bntAlterar_Click);
            // 
            // bntLimparAlterar
            // 
            this.bntLimparAlterar.Location = new System.Drawing.Point(44, 353);
            this.bntLimparAlterar.Name = "bntLimparAlterar";
            this.bntLimparAlterar.Size = new System.Drawing.Size(111, 52);
            this.bntLimparAlterar.TabIndex = 94;
            this.bntLimparAlterar.Text = "Limpar";
            this.bntLimparAlterar.UseSelectable = true;
            this.bntLimparAlterar.Click += new System.EventHandler(this.bntLimparAlterar_Click);
            // 
            // tbRemover
            // 
            this.tbRemover.Controls.Add(this.groupBox8);
            this.tbRemover.Controls.Add(this.groupBox7);
            this.tbRemover.Controls.Add(this.bntRemover);
            this.tbRemover.HorizontalScrollbarBarColor = true;
            this.tbRemover.HorizontalScrollbarHighlightOnWheel = false;
            this.tbRemover.HorizontalScrollbarSize = 10;
            this.tbRemover.Location = new System.Drawing.Point(4, 38);
            this.tbRemover.Name = "tbRemover";
            this.tbRemover.Size = new System.Drawing.Size(364, 442);
            this.tbRemover.TabIndex = 2;
            this.tbRemover.Text = "Remover";
            this.tbRemover.VerticalScrollbarBarColor = true;
            this.tbRemover.VerticalScrollbarHighlightOnWheel = false;
            this.tbRemover.VerticalScrollbarSize = 10;
            // 
            // groupBox8
            // 
            this.groupBox8.BackColor = System.Drawing.Color.Transparent;
            this.groupBox8.Controls.Add(this.txtExcPizza);
            this.groupBox8.Location = new System.Drawing.Point(40, 72);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(299, 56);
            this.groupBox8.TabIndex = 96;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Código";
            // 
            // txtExcPizza
            // 
            this.txtExcPizza.Lines = new string[0];
            this.txtExcPizza.Location = new System.Drawing.Point(17, 19);
            this.txtExcPizza.MaxLength = 32767;
            this.txtExcPizza.Name = "txtExcPizza";
            this.txtExcPizza.PasswordChar = '\0';
            this.txtExcPizza.ReadOnly = true;
            this.txtExcPizza.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtExcPizza.SelectedText = "";
            this.txtExcPizza.Size = new System.Drawing.Size(268, 23);
            this.txtExcPizza.TabIndex = 85;
            this.txtExcPizza.UseSelectable = true;
            // 
            // groupBox7
            // 
            this.groupBox7.BackColor = System.Drawing.Color.Transparent;
            this.groupBox7.Controls.Add(this.txtExcSabor);
            this.groupBox7.Location = new System.Drawing.Point(40, 134);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(299, 56);
            this.groupBox7.TabIndex = 95;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Sabores";
            // 
            // txtExcSabor
            // 
            this.txtExcSabor.Lines = new string[0];
            this.txtExcSabor.Location = new System.Drawing.Point(17, 19);
            this.txtExcSabor.MaxLength = 32767;
            this.txtExcSabor.Name = "txtExcSabor";
            this.txtExcSabor.PasswordChar = '\0';
            this.txtExcSabor.ReadOnly = true;
            this.txtExcSabor.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtExcSabor.SelectedText = "";
            this.txtExcSabor.Size = new System.Drawing.Size(268, 23);
            this.txtExcSabor.TabIndex = 85;
            this.txtExcSabor.UseSelectable = true;
            // 
            // bntRemover
            // 
            this.bntRemover.ActiveControl = null;
            this.bntRemover.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bntRemover.Location = new System.Drawing.Point(40, 228);
            this.bntRemover.Name = "bntRemover";
            this.bntRemover.Size = new System.Drawing.Size(285, 80);
            this.bntRemover.Style = MetroFramework.MetroColorStyle.Red;
            this.bntRemover.TabIndex = 93;
            this.bntRemover.Text = "Remover";
            this.bntRemover.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bntRemover.Theme = MetroFramework.MetroThemeStyle.Light;
            this.bntRemover.UseSelectable = true;
            this.bntRemover.Click += new System.EventHandler(this.bntRemover_Click);
            // 
            // dgvPizzas
            // 
            this.dgvPizzas.AllowUserToOrderColumns = true;
            this.dgvPizzas.AllowUserToResizeRows = false;
            this.dgvPizzas.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvPizzas.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvPizzas.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvPizzas.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPizzas.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvPizzas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvPizzas.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvPizzas.EnableHeadersVisualStyles = false;
            this.dgvPizzas.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvPizzas.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvPizzas.Location = new System.Drawing.Point(32, 63);
            this.dgvPizzas.Name = "dgvPizzas";
            this.dgvPizzas.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(17)))), ((int)(((byte)(65)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(19)))), ((int)(((byte)(73)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPizzas.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvPizzas.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvPizzas.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPizzas.Size = new System.Drawing.Size(428, 125);
            this.dgvPizzas.Style = MetroFramework.MetroColorStyle.Red;
            this.dgvPizzas.TabIndex = 72;
            this.dgvPizzas.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPizzas_CellClick);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(20, 671);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(460, 49);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox2.TabIndex = 74;
            this.pictureBox2.TabStop = false;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // frmTabelaPreco
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(500, 740);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.tbMenuTabela);
            this.Controls.Add(this.dgvPizzas);
            this.MaximizeBox = false;
            this.Name = "frmTabelaPreco";
            this.Style = MetroFramework.MetroColorStyle.Red;
            this.Text = "Tabela de Preço";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tbMenuTabela.ResumeLayout(false);
            this.tpAdicionar.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tpAlterar.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.tbRemover.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPizzas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private MetroFramework.Controls.MetroTabControl tbMenuTabela;
        private MetroFramework.Controls.MetroTabPage tpAdicionar;
        private System.Windows.Forms.GroupBox groupBox3;
        private MetroFramework.Controls.MetroTextBox txtAdiSabores;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtAdiInfomacoes;
        private System.Windows.Forms.GroupBox groupBox1;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroTextBox txtAdiMedia;
        private MetroFramework.Controls.MetroTextBox txtAdiPequena;
        private MetroFramework.Controls.MetroTextBox txtAdiGrande;
        private MetroFramework.Controls.MetroTile bntAdicionar;
        private MetroFramework.Controls.MetroButton bntLimpar;
        private MetroFramework.Controls.MetroTabPage tpAlterar;
        private MetroFramework.Controls.MetroTabPage tbRemover;
        private MetroFramework.Controls.MetroGrid dgvPizzas;
        private System.Windows.Forms.GroupBox groupBox4;
        private MetroFramework.Controls.MetroTextBox txtAltSabor;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox txtAltInformacoes;
        private System.Windows.Forms.GroupBox groupBox6;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroTextBox txtAltMedia;
        private MetroFramework.Controls.MetroTextBox txtAltPequena;
        private MetroFramework.Controls.MetroTextBox txtAltGrande;
        private MetroFramework.Controls.MetroTile bntAlterar;
        private MetroFramework.Controls.MetroButton bntLimparAlterar;
        private System.Windows.Forms.GroupBox groupBox7;
        private MetroFramework.Controls.MetroTextBox txtExcSabor;
        private MetroFramework.Controls.MetroTile bntRemover;
        private System.Windows.Forms.GroupBox groupBox8;
        private MetroFramework.Controls.MetroTextBox txtExcPizza;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}