﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace Pizzaria.Modelos
{
    public class ModelosAcesso
    {
        private int idAcessos;
        public int IdAcessos { get { return idAcessos; } set { idAcessos = value; } }

        private string acesso;
        public string Acesso { get { return acesso; } set { acesso = value; } }

    }
}
