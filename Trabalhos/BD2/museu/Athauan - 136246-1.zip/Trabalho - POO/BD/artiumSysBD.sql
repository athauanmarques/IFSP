-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: artiumsystem
-- ------------------------------------------------------
-- Server version	5.7.19-log

Drop Database if exists artiumsystem;
create database artiumsystem;
use artiumsystem;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `acervo`
--

DROP TABLE IF EXISTS `acervo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `acervo` (
  `idAcervo` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(45) NOT NULL,
  `descricao` longtext,
  `periodo` enum('temporario','permanente') NOT NULL,
  `dataInicio` date DEFAULT NULL,
  `dataFinal` date DEFAULT NULL,
  `cidade` varchar(25) NOT NULL,
  `endereco` varchar(110) NOT NULL,
  `estado` varchar(2) NOT NULL DEFAULT 'SP',
  `cep` varchar(9) DEFAULT NULL,
  `responsavel` varchar(25) NOT NULL,
  `telResponvel` varchar(12) NOT NULL,
  `limiteReserva` int(11) NOT NULL,
  `maxVisitante` int(11) NOT NULL,
  `enviarConvites` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`idAcervo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acervo`
--

LOCK TABLES `acervo` WRITE;
/*!40000 ALTER TABLE `acervo` DISABLE KEYS */;
/*!40000 ALTER TABLE `acervo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estoque`
--

DROP TABLE IF EXISTS `estoque`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `estoque` (
  `idEstoque` int(11) NOT NULL AUTO_INCREMENT,
  `codProduto` varchar(20) NOT NULL,
  `produto` varchar(45) NOT NULL,
  `marca` varchar(15) NOT NULL,
  `descricaoProduto` longtext,
  `preco` double NOT NULL,
  `qtsEstoque` int(11) NOT NULL,
  PRIMARY KEY (`idEstoque`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estoque`
--

LOCK TABLES `estoque` WRITE;
/*!40000 ALTER TABLE `estoque` DISABLE KEYS */;
/*!40000 ALTER TABLE `estoque` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login` (
  `idLogin` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `codCartao` varchar(20) NOT NULL,
  `senha` longtext NOT NULL,
  `tipoAcesso` enum('visitante','funcionario') NOT NULL,
  PRIMARY KEY (`idLogin`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login`
--

LOCK TABLES `login` WRITE;
/*!40000 ALTER TABLE `login` DISABLE KEYS */;
/*!40000 ALTER TABLE `login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservas_convites`
--

DROP TABLE IF EXISTS `reservas_convites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reservas_convites` (
  `idAcervo_tbAcervo` int(11) NOT NULL,
  `idUsuario_tbUsuario` int(11) NOT NULL,
  `reservar` int(11) DEFAULT '0',
  `convidado` binary(1) DEFAULT '0',
  PRIMARY KEY (`idAcervo_tbAcervo`,`idUsuario_tbUsuario`),
  KEY `fk_Acervo_has_usuario_usuario1_idx` (`idUsuario_tbUsuario`),
  KEY `fk_Acervo_has_usuario_Acervo1_idx` (`idAcervo_tbAcervo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservas_convites`
--

LOCK TABLES `reservas_convites` WRITE;
/*!40000 ALTER TABLE `reservas_convites` DISABLE KEYS */;
/*!40000 ALTER TABLE `reservas_convites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `restauracao`
--

DROP TABLE IF EXISTS `restauracao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `restauracao` (
  `idRestauracao` int(11) NOT NULL AUTO_INCREMENT,
  `statusRestaurar` enum('analise','andamento','concluido','cancelado') NOT NULL DEFAULT 'analise',
  `prazoInicio` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `prazoFinal` datetime NOT NULL,
  `vezesRestaurado` int(11) DEFAULT '0',
  `idAcervo_tbAcervo` int(11) NOT NULL,
  `idUsuario_tbUsuario` int(11) NOT NULL,
  PRIMARY KEY (`idRestauracao`,`idAcervo_tbAcervo`,`idUsuario_tbUsuario`),
  KEY `fk_restauracao_Acervo1_idx` (`idAcervo_tbAcervo`),
  KEY `fk_restauracao_usuario1_idx` (`idUsuario_tbUsuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `restauracao`
--

LOCK TABLES `restauracao` WRITE;
/*!40000 ALTER TABLE `restauracao` DISABLE KEYS */;
/*!40000 ALTER TABLE `restauracao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario` (
  `idUsuario` int(11) NOT NULL AUTO_INCREMENT,
  `telefone` varchar(12) NOT NULL,
  `dataNascimento` date NOT NULL,
  `sexo` varchar(1) NOT NULL,
  `email` varchar(45) NOT NULL,
  `receberConvite` tinyint(4) DEFAULT '0',
  `cargo` varchar(80) DEFAULT 'colaborador',
  `numeroRA` varchar(20) DEFAULT NULL,
  `idLogin_tbLogin` int(11) NOT NULL,
  PRIMARY KEY (`idUsuario`,`idLogin_tbLogin`),
  KEY `fk_usuario_Login_idx` (`idLogin_tbLogin`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vendas`
--

DROP TABLE IF EXISTS `vendas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vendas` (
  `idEstoque_tbEstoque` int(11) NOT NULL,
  `idUsuario_tbUsuario` int(11) NOT NULL,
  `quantidadeVendas` int(11) NOT NULL,
  `dataVenda` datetime NOT NULL,
  PRIMARY KEY (`idEstoque_tbEstoque`,`idUsuario_tbUsuario`),
  KEY `fk_estoque_has_usuario_usuario1_idx` (`idUsuario_tbUsuario`),
  KEY `fk_estoque_has_usuario_estoque1_idx` (`idEstoque_tbEstoque`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vendas`
--

LOCK TABLES `vendas` WRITE;
/*!40000 ALTER TABLE `vendas` DISABLE KEYS */;
/*!40000 ALTER TABLE `vendas` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-09-12 14:43:23


drop procedure if exists prVerificarLogin;

delimiter ||
create procedure prVerificarLogin(in jCodACartao varchar(20), in jSenha longtext,in jTipoUsuario varchar(80), out msg varchar(80))
begin
	declare verificaSenha longtext;
    declare verificaCartao varchar(100);
    declare verificaTipAcesso varchar(100);
    
    select senha from login where senha = md5(jSenha) into verificaSenha;
    select codCartao from login where codCartao = jCodACartao into verificaCartao;
    select tipoAcesso from login where codCartao = jCodACartao and tipoAcesso = jTipoUsuario into verificaTipAcesso;
    
       if verificaSenha <> md5(jSenha) and verificaTipAcesso = 'funcionario'then
			set msg = 'senha esta errada';
	   elseif verificaCartao <> jCodACartao and verificaTipAcesso = 'funcionario' then
			set msg = 'número de cartão esta errada';
	   elseif verificaSenha <> md5(jSenha) and verificaTipAcesso = 'visitante' then
			set msg = 'senha esta errada';
	   elseif verificaCartao <> jCodACartao and verificaTipAcesso = 'visitante' then
			set msg = 'número de cartão esta errada';
	   elseif verificaCartao = jCodACartao and verificaSenha = md5(jSenha) and verificaTipAcesso = 'visitante' then
			set msg = 'visitante';
		elseif verificaCartao = jCodACartao and verificaSenha = md5(jSenha) and verificaTipAcesso = 'funcionario' then
			set msg = 'funcionario';
	   else
		set msg = 'tente novamente, verifique o tipo de usuario';
end if;
		select msg;
	end;

|| delimiter ;

drop procedure if exists prRedifinirSenha;



